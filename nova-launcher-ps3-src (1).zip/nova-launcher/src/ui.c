/* Interfaz horizontal estilo "consola moderna": pestañas arriba a la izquierda,
 * iconos y reloj a la derecha, fila de cuadraditos con el seleccionado más grande,
 * fondo a pantalla completa con el arte del elemento, título + botón abajo,
 * carátula a la derecha y tres paneles inferiores.
 * Todo es dibujo original por software (sin recursos de Sony). */
#include "ui.h"
#include "input.h"
#include "launch.h"
#include "library.h"
#include "platform.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define NSEC 4
#define NART 6
#define NSPR 16

/* Tarjeta ya renderizada (contenido + máscara redondeada) para no recalcularla cada fotograma. */
typedef struct { int idx, w, age; uint32_t *px; uint8_t *mask; } Sprite;
static const char *SEC_NAME[NSEC] = { "Juegos", "Multimedia", "Aplicaciones", "Biblioteca" };
static const float SEC_HUE[NSEC] = { 218.f, 262.f, 192.f, 236.f };
static const char *CHIP_NAME[3] = { "Juegos instalados", "Aplicaciones instaladas", "Favoritos" };

struct App {
    Surf s;
    Library lib;
    Pad pad;
    float K, t;
    int section, chip, on_chips;
    int view[MAX_ITEMS], nview, sel;
    int chip_count[3];
    float scroll, grow[MAX_ITEMS];
    float sec_t;
    int sec_dir, prev_section;
    int sel_mem[NSEC];
    float ul_x, ul_w;
    char toast[160];
    float toast_t;
    int toast_err;
    int launching, exit_flag;
    float launch_t;
    uint32_t *bg[NSEC];
    Sprite spr[NSPR];
    Sprite art[NART];      /* fondos a pantalla completa por elemento (caché) */
    int frame_no, dirty, toast_was;
};

static float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
static int imin(int a, int b) { return a < b ? a : b; }

/* ------------------------------------------------------------ fondo estático */

static void bg_build(uint32_t *buf, int w, int h, float hue)
{
    Surf t = { w, h, buf };
    uint32_t top = RGB(5, 9, 26), bot = RGB(9, 28, 74), tint = gfx_hsv(hue, 0.75f, 0.9f);
    for (int y = 0; y < h; y++) {
        float k = (float)y / (float)(h - 1);
        uint32_t row = gfx_mix(gfx_mix(top, bot, k * k * 0.9f + k * 0.1f), tint, 0.10f);
        for (int x = 0; x < w; x++) buf[y * w + x] = row;
    }
    gfx_radial(&t, w * .16f, h * .10f, h * .95f, gfx_hsv(hue, 0.70f, 1.0f), 105);
    gfx_radial(&t, w * .88f, h * .92f, h * .85f, gfx_hsv(hue + 28, 0.65f, 0.95f), 80);
    gfx_radial(&t, w * .55f, h * .38f, h * .55f, RGB(120, 160, 255), 24);
    /* ondas de luz suaves, a modo de profundidad */
    for (int k = 0; k < 3; k++) {
        float thick = h * (0.05f + 0.012f * k);
        for (int x = 0; x < w; x++) {
            float yc = h * (0.60f + 0.075f * k) + sinf(x * (0.0042f - 0.0009f * k) + k * 1.7f) * h * 0.055f;
            for (int dy = -(int)thick; dy <= (int)thick; dy++) {
                float f = 1.f - fabsf((float)dy) / thick;
                gfx_blend(&t, x, (int)yc + dy, RGB(150, 190, 255), (int)(22 * f * f));
            }
        }
    }
    /* viñeta */
    for (int y = 0; y < h; y++)
        for (int x = 0; x < w; x++) {
            float dx = (x - w * .5f) / (w * .5f), dy = (y - h * .5f) / (h * .5f);
            float d = sqrtf(dx * dx * .75f + dy * dy);
            float v = clampf((d - 0.62f) / 0.75f, 0.f, 1.f);
            uint32_t p = buf[y * w + x];
            float f = 1.f - 0.45f * v * v;
            buf[y * w + x] = RGB((int)(((p >> 16) & 255) * f), (int)(((p >> 8) & 255) * f), (int)((p & 255) * f));
        }
    /* sombreado superior para que las pestañas se lean sobre cualquier fondo */
    float kk = h / 1080.f;
    for (int y = 0; y < (int)(230 * kk); y += 2)
        gfx_rect(&t, 0, y, w, 2, RGB(0, 4, 16), (int)(110 * (1.f - y / (230.f * kk))));
}

/* ------------------------------------------------------------------- vistas */

static void sprites_flush(App *a)
{
    for (int i = 0; i < NSPR; i++) {
        free(a->spr[i].px); free(a->spr[i].mask);
        memset(&a->spr[i], 0, sizeof a->spr[i]);
        a->spr[i].idx = -1;
    }
    for (int i = 0; i < NART; i++) {
        free(a->art[i].px);
        memset(&a->art[i], 0, sizeof a->art[i]);
        a->art[i].idx = -1;
    }
}

static void rebuild_view(App *a, int keep_item)
{
    sprites_flush(a);
    a->nview = 0;
    for (int c = 0; c < 3; c++) a->chip_count[c] = 0;
    for (int i = 0; i < a->lib.n; i++) {
        const Item *it = &a->lib.items[i];
        if (it->available) {
            if (it->kind == KIND_GAME) a->chip_count[0]++;
            if (it->kind == KIND_APP) a->chip_count[1]++;
            if (it->favorite) a->chip_count[2]++;
        }
        int ok = 0;
        switch (a->section) {
        case 0: ok = it->kind == KIND_GAME; break;
        case 1: ok = it->kind == KIND_MEDIA; break;
        case 2: ok = it->kind == KIND_APP; break;
        default:
            if (!it->available) ok = 0;
            else if (a->chip == 0) ok = it->kind == KIND_GAME;
            else if (a->chip == 1) ok = it->kind == KIND_APP;
            else ok = it->favorite;
        }
        if (ok) a->view[a->nview++] = i;
    }
    if (keep_item >= 0)
        for (int v = 0; v < a->nview; v++) if (a->view[v] == keep_item) { a->sel = v; break; }
    if (a->sel >= a->nview) a->sel = a->nview - 1;
    if (a->sel < 0) a->sel = 0;
}

static void set_toast(App *a, const char *msg, int err)
{
    snprintf(a->toast, sizeof a->toast, "%s", msg);
    a->toast_t = 2.6f;
    a->toast_err = err;
}

static void set_section(App *a, int s, int dir)
{
    if (s == a->section) return;
    a->sel_mem[a->section] = a->sel;
    a->prev_section = a->section;
    a->section = s;
    a->sec_t = 0;
    a->sec_dir = dir;
    a->on_chips = 0;
    a->lib.section = s;
    a->sel = a->sel_mem[s];
    rebuild_view(a, -1);
    a->scroll = (float)a->sel;
    memset(a->grow, 0, sizeof a->grow);
    lib_save_config(&a->lib);
    plat_sound(SND_SECTION);
}

/* ------------------------------------------------------------------ creación */

App *app_create(int w, int h)
{
    App *a = calloc(1, sizeof *a);
    if (!a) return NULL;
    a->s.w = w;
    a->s.h = h;
    a->s.px = malloc((size_t)w * h * 4);
    a->K = h / 1080.f;
    lib_init(&a->lib);
    lib_scan(&a->lib);
    lib_load_config(&a->lib);
    a->bg[0] = malloc((size_t)w * h * 4);          /* fondo de reserva (sección vacía) */
    if (a->bg[0]) bg_build(a->bg[0], w, h, SEC_HUE[0]);
    a->section = a->prev_section = a->lib.section;
    a->sec_t = 1.f;
    rebuild_view(a, -1);
    a->scroll = (float)a->sel;
    a->ul_x = 0;
    a->ul_w = 0;
    return a;
}

void app_destroy(App *a)
{
    if (!a) return;
    sprites_flush(a);
    free(a->bg[0]);
    free(a->s.px);
    free(a);
}

Surf *app_surface(App *a) { return &a->s; }
int app_wants_exit(const App *a) { return a->exit_flag; }

/* ---------------------------------------------------------------- lógica */

static void activate(App *a)
{
    if (!a->nview) return;
    int idx = a->view[a->sel];
    const Item *it = &a->lib.items[idx];
    if (!it->available) {
        set_toast(a, "No está instalado en esta consola", 1);
        plat_sound(SND_ERROR);
        return;
    }
    char err[120] = "";
    plat_sound(SND_SELECT);
    if (launch_item(it, err, sizeof err) == 0) {
        char m[160];
        snprintf(m, sizeof m, "Iniciando %s…", it->name);
        set_toast(a, m, 0);
        a->toast_t = 4.f;
        a->launching = 1;
        a->launch_t = 0;
    } else {
        set_toast(a, err[0] ? err : "No se pudo iniciar", 1);
        plat_sound(SND_ERROR);
    }
}

static void update(App *a, float dt)
{
    Pad *p = &a->pad;
    a->t += dt;
    a->sec_t = clampf(a->sec_t + dt * 3.4f, 0.f, 1.f);
    if (a->toast_t > 0) a->toast_t -= dt;

    if (a->launching) {
        a->launch_t += dt;
        if (a->launch_t > 1.1f && a->lib.exit_after) a->exit_flag = 1;
        if (a->launch_t > 1.1f && !a->lib.exit_after) a->launching = 0;
    } else {
        if (p->pressed & PB_R1) set_section(a, (a->section + 1) % NSEC, +1);
        else if (p->pressed & PB_L1) set_section(a, (a->section + NSEC - 1) % NSEC, -1);
        else if (a->on_chips) {
            if ((p->pressed & PB_LEFT) && a->chip > 0) { a->chip--; a->sel = 0; rebuild_view(a, -1); plat_sound(SND_MOVE); }
            if ((p->pressed & PB_RIGHT) && a->chip < 2) { a->chip++; a->sel = 0; rebuild_view(a, -1); plat_sound(SND_MOVE); }
            if (p->pressed & (PB_DOWN | PB_CROSS | PB_CIRCLE)) { a->on_chips = 0; plat_sound(SND_MOVE); }
        } else {
            if ((p->pressed & PB_RIGHT) && a->sel < a->nview - 1) { a->sel++; plat_sound(SND_MOVE); }
            if ((p->pressed & PB_LEFT) && a->sel > 0) { a->sel--; plat_sound(SND_MOVE); }
            if ((p->pressed & PB_UP) && a->section == 3) { a->on_chips = 1; plat_sound(SND_MOVE); }
            if (p->pressed & PB_CROSS) activate(a);
            if ((p->pressed & PB_TRI) && a->nview) {
                int idx = a->view[a->sel];
                lib_toggle_fav(&a->lib, idx);
                set_toast(a, a->lib.items[idx].favorite ? "Añadido a favoritos" : "Quitado de favoritos", 0);
                rebuild_view(a, idx);
                lib_save_config(&a->lib);
                plat_sound(SND_SELECT);
            }
            if (p->pressed & PB_CIRCLE) {
                if (a->sel > 0) { a->sel = 0; plat_sound(SND_BACK); }
                else if (a->section != 0) set_section(a, 0, -1);
            }
        }
    }

    int moving = 0;
    a->scroll += ((float)a->sel - a->scroll) * (1.f - expf(-dt * 11.f));
    if (fabsf(a->scroll - a->sel) < 0.004f) a->scroll = (float)a->sel; else moving = 1;
    for (int i = 0; i < a->nview; i++) {
        float target = (i == a->sel) ? (a->on_chips ? 0.5f : 1.f) : 0.f;
        a->grow[i] += (target - a->grow[i]) * (1.f - expf(-dt * 14.f));
        if (fabsf(a->grow[i] - target) < 0.004f) a->grow[i] = target; else moving = 1;
    }
    if (a->pad.pressed || moving || a->sec_t < 1.f || a->toast_t > 0 || a->toast_was ||
        a->launching || a->lib.fx)
        a->dirty = 1;
    a->toast_was = a->toast_t > 0;
}

/* --------------------------------------------------------------- dibujado */

static unsigned hash_str(const char *s)
{
    unsigned h = 2166136261u;
    while (*s) h = (h ^ (unsigned char)*s++) * 16777619u;
    return h;
}

/* Contenido de la tarjeta en coordenadas locales (0,0)-(w,w). */
static void render_card(App *a, const Item *it, Sprite *sp, int w)
{
    Surf t = { w, w, sp->px };
    float K = a->K, r = 0.085f * w;
    (void)K;
    uint32_t c0 = gfx_hsv((float)it->hue, 0.62f, 0.98f), c1 = gfx_hsv((float)it->hue + 38.f, 0.90f, 0.40f);
    RR clip = { 0, 0, (float)w, (float)w, r };
    memset(sp->px, 0, (size_t)w * w * 4);
    gfx_rrect_mask(sp->mask, w, w, r);
    gfx_rrect_grad(&t, 0, 0, (float)w, (float)w, r, c0, c1, 255);

    unsigned hs = hash_str(it->id);
    float u1 = ((hs >> 3) & 15) / 15.f, u2 = ((hs >> 8) & 15) / 15.f, u3 = ((hs >> 13) & 15) / 15.f;
    gfx_circle(&t, w * (0.15f + 0.5f * u1), w * (0.10f + 0.3f * u2), w * (0.42f + 0.14f * u3),
               gfx_hsv((float)it->hue + 20.f, 0.35f, 1.f), 46, &clip);
    gfx_circle(&t, w * (0.95f - 0.4f * u2), w * (0.85f - 0.25f * u1), w * (0.5f + 0.1f * u1),
               gfx_hsv((float)it->hue - 25.f, 0.8f, 0.25f), 90, &clip);
    gfx_line(&t, -w * .1f, w * (0.55f + 0.2f * u3), w * 1.1f, w * (0.05f + 0.2f * u2),
             w * .22f, RGB(255, 255, 255), 24, &clip);

    float msz = w * (strlen(it->mono) > 1 ? 0.34f : 0.44f);
    float mw = gfx_text_w(it->mono, msz), mh = gfx_text_lineh(msz);
    float shx = w * 0.006f;
    gfx_text(&t, (w - mw) * .5f + shx, w * .50f - mh * .5f + shx * 1.5f, it->mono, msz, RGB(0, 8, 40), 70);
    gfx_text(&t, (w - mw) * .5f, w * .50f - mh * .5f, it->mono, msz, RGB(255, 255, 255), 238);

    if (!it->available) {
        gfx_rrect(&t, 0, 0, (float)w, (float)w, r, RGB(5, 10, 28), 150);
        gfx_rrect(&t, w * .30f, w * .80f, w * .40f, w * .07f, w * .035f, RGB(255, 205, 120), 200);   /* barra ámbar = no instalado */
    }
    if (it->favorite) gfx_star(&t, w - w * .12f, w * .13f, w * .075f, RGB(255, 208, 84), 245);
}

static Sprite *get_sprite(App *a, int item_idx, int w)
{
    Sprite *victim = &a->spr[0];
    for (int i = 0; i < NSPR; i++) {
        Sprite *sp = &a->spr[i];
        if (sp->px && sp->idx == item_idx && sp->w == w) { sp->age = a->frame_no; return sp; }
        if (!sp->px) victim = sp;
        else if (victim->px && sp->age < victim->age) victim = sp;
    }
    free(victim->px); free(victim->mask);
    victim->px = malloc((size_t)w * w * 4);
    victim->mask = malloc((size_t)w * w);
    victim->idx = item_idx; victim->w = w; victim->age = a->frame_no;
    if (!victim->px || !victim->mask) { free(victim->px); free(victim->mask); victim->px = NULL; victim->mask = NULL; return NULL; }
    render_card(a, &a->lib.items[item_idx], victim, w);
    return victim;
}

static void draw_card(App *a, int item_idx, float x, float y, float wf, float grow, int ga, uint32_t accent)
{
    Surf *s = &a->s;
    float K = a->K;
    int w = ((int)(wf / (6 * K) + .5f)) * (int)(6 * K + .5f);   /* ancho cuantizado: reutiliza sprites */
    if (w < 16) w = 16;
    float r = 0.085f * w;
    float xo = floorf(x + .5f), yo = floorf(y + (wf - w) + .5f);

    /* sombra barata: tres capas translúcidas en lugar de un desenfoque por píxel */
    gfx_rrect(s, xo - 10 * K, yo + 2 * K, w + 20 * K, w + 20 * K, r + 10 * K, RGB(0, 0, 14), 26 * ga / 255);
    gfx_rrect(s, xo - 5 * K, yo + 6 * K, w + 10 * K, w + 10 * K, r + 5 * K, RGB(0, 0, 14), 38 * ga / 255);
    if (grow > 0.02f) {
        float pulse = a->lib.fx ? 0.78f + 0.22f * sinf(a->t * 3.4f) : 0.9f;
        gfx_glow(s, xo, yo, (float)w, (float)w, r, (10.f + 8.f * pulse) * K, accent, (int)(190 * grow * pulse) * ga / 255);
    }
    Sprite *sp = get_sprite(a, item_idx, w);
    if (sp) gfx_blit_mask(s, sp->px, sp->mask, w, w, (int)xo, (int)yo, ga);
    if (grow > 0.05f)
        gfx_rrect_ring(s, xo - 5 * K, yo - 5 * K, w + 10 * K, w + 10 * K, r + 5 * K, 4.f * K, RGB(255, 255, 255), (int)(238 * grow) * ga / 255);
}

/* ------------------------------------------------------- fondo por elemento */

/* Arte de pantalla completa, original: degradado del color del elemento, luces,
 * una "ola" luminosa arriba y la inicial enorme. Coste bajo (sin sqrt por píxel). */
static void render_art(App *a, const Item *it, Sprite *sp)
{
    int w = a->s.w, h = a->s.h;
    Surf t = { w, h, sp->px };
    float hue = (float)it->hue;
    uint32_t top = gfx_hsv(hue, 0.78f, 0.62f), mid = gfx_hsv(hue + 14.f, 0.92f, 0.30f), bot = gfx_hsv(hue + 26.f, 0.95f, 0.07f);
    for (int y = 0; y < h; y++) {
        float k = (float)y / (float)(h - 1);
        uint32_t row = k < 0.5f ? gfx_mix(top, mid, k * 2.f) : gfx_mix(mid, bot, (k - 0.5f) * 2.f);
        uint32_t *p = &sp->px[y * w];
        for (int x = 0; x < w; x++) p[x] = row;
    }
    unsigned hs = hash_str(it->id);
    float u1 = ((hs >> 3) & 15) / 15.f, u2 = ((hs >> 8) & 15) / 15.f;
    gfx_radial(&t, w * (0.58f + 0.2f * u1), h * (0.40f + 0.1f * u2), h * 0.80f, gfx_hsv(hue + 12.f, 0.55f, 1.f), 120);
    gfx_radial(&t, w * 0.10f, h * 0.05f, h * 0.55f, gfx_hsv(hue - 20.f, 0.5f, 1.f), 70);
    /* ola luminosa en la parte alta */
    for (int k = 0; k < 2; k++) {
        float thick = h * (0.075f - 0.02f * k);
        for (int x = 0; x < w; x++) {
            float yc = h * (0.10f + 0.06f * k) + sinf(x * (0.0032f + 0.0008f * k) + k * 2.1f + u1 * 3.f) * h * 0.06f;
            for (int dy = -(int)thick; dy <= (int)thick; dy++) {
                float f = 1.f - fabsf((float)dy) / thick;
                gfx_blend(&t, x, (int)yc + dy, gfx_hsv(hue + 30.f, 0.35f, 1.f), (int)(70 * f * f));
            }
        }
    }
    /* inicial gigante */
    float msz = h * (strlen(it->mono) > 1 ? 0.78f : 1.0f);
    float mw = gfx_text_w(it->mono, msz);
    gfx_text(&t, w * 0.60f - mw * .5f, h * 0.44f - gfx_text_lineh(msz) * .5f, it->mono, msz, RGB(255, 255, 255), 34);
    /* sombreado inferior e izquierdo para que el texto se lea */
    for (int y = (int)(h * 0.45f); y < h; y++) {
        float k = ((float)y / h - 0.45f) / 0.55f;
        gfx_rect(&t, 0, y, w, 1, RGB(0, 0, 8), (int)(190 * k));
    }
    gfx_radial(&t, 0.f, h * 0.85f, h * 0.85f, RGB(0, 0, 10), 170);
}

static Sprite *get_art(App *a, int item_idx)
{
    Sprite *v = &a->art[0];
    for (int i = 0; i < NART; i++) {
        Sprite *sp = &a->art[i];
        if (sp->px && sp->idx == item_idx) { sp->age = a->frame_no; return sp; }
        if (!sp->px) v = sp; else if (v->px && sp->age < v->age) v = sp;
    }
    free(v->px);
    v->px = malloc((size_t)a->s.w * a->s.h * 4);
    v->idx = item_idx; v->age = a->frame_no;
    if (!v->px) return NULL;
    render_art(a, &a->lib.items[item_idx], v);
    return v;
}

/* ------------------------------------------------------------- piezas sueltas */

static void draw_search(Surf *s, float cx, float cy, float K, int al)
{
    gfx_circle_ring(s, cx - 3 * K, cy - 3 * K, 9 * K, 2.6f * K, RGB(255, 255, 255), al);
    gfx_line(s, cx + 4 * K, cy + 4 * K, cx + 12 * K, cy + 12 * K, 3.2f * K, RGB(255, 255, 255), al, NULL);
}

static void draw_gear(Surf *s, float cx, float cy, float K, int al)
{
    for (int k = 0; k < 8; k++) {
        float ang = k * 0.7853982f;
        gfx_line(s, cx + cosf(ang) * 9 * K, cy + sinf(ang) * 9 * K, cx + cosf(ang) * 14 * K, cy + sinf(ang) * 14 * K, 4.5f * K, RGB(255, 255, 255), al, NULL);
    }
    gfx_circle_ring(s, cx, cy, 9 * K, 4.2f * K, RGB(255, 255, 255), al);
    gfx_circle_ring(s, cx, cy, 3.6f * K, 2.2f * K, RGB(255, 255, 255), al);
}

static void draw_lock(Surf *s, float x, float y, float K, uint32_t c, int al)
{
    gfx_circle_ring(s, x + 8 * K, y + 7 * K, 5.5f * K, 2.4f * K, c, al);
    gfx_rrect(s, x, y + 8 * K, 16 * K, 12 * K, 3 * K, c, al);
}

static void draw_chip(Surf *s, float K, float x, float y, float h, const char *lab, float tsz, int al)
{
    float tw = gfx_text_w(lab, tsz), w = tw + h * 0.9f;
    gfx_rrect(s, x, y, w, h, h * .5f, RGB(10, 12, 24), 175 * al / 255);
    gfx_text(s, x + h * .45f, y + (h - gfx_text_lineh(tsz)) * .5f, lab, tsz, RGB(255, 255, 255), 240 * al / 255);
    (void)K;
}

static void draw_frame(App *a)
{
    Surf *s = &a->s;
    int W = s->w, H = s->h;
    float K = a->K;
    float ease = 1.f - powf(1.f - a->sec_t, 3.f);
    int ga = (int)(255 * ease);
    int n = a->nview;
    uint32_t accent = RGB(255, 255, 255);
    const Item *cur = n > 0 ? &a->lib.items[a->view[a->sel]] : NULL;

    /* fondo: arte del elemento seleccionado */
    Sprite *art = cur ? get_art(a, a->view[a->sel]) : NULL;
    if (art) memcpy(s->px, art->px, (size_t)W * H * 4);
    else if (a->bg[0]) memcpy(s->px, a->bg[0], (size_t)W * H * 4);
    if (a->lib.fx) {   /* luz que se desplaza muy despacio: fondo dinámico */
        float ox = W * (0.55f + 0.30f * sinf(a->t * 0.17f)), oy = H * (0.40f + 0.18f * cosf(a->t * 0.12f));
        gfx_radial(s, ox, oy, H * 0.26f, RGB(200, 220, 255), 22);
    }
    /* sombreado superior para que pestañas e iconos se lean */
    for (int y = 0; y < (int)(200 * K); y += 2)
        gfx_rect(s, 0, y, W, 2, RGB(0, 2, 12), (int)(120 * (1.f - y / (200.f * K))));

    /* pestañas (arriba a la izquierda) */
    {
        float tsz = 36 * K, tx = 90 * K, ty = 42 * K, gap = 54 * K;
        for (int i = 0; i < NSEC; i++) {
            int on = (i == a->section);
            gfx_text(s, tx, ty, SEC_NAME[i], tsz, on ? RGB(255, 255, 255) : RGB(214, 220, 238), on ? 255 : 150);
            tx += gfx_text_w(SEC_NAME[i], tsz) + gap;
        }
    }
    /* iconos, avatar y reloj (arriba a la derecha) */
    {
        float cy = 62 * K;
        draw_search(s, 1374 * K, cy, K, 235);
        draw_gear(s, 1480 * K, cy, K, 235);
        gfx_circle(s, 1590 * K, cy, 23 * K, RGB(44, 58, 110), 255, NULL);
        gfx_circle_ring(s, 1590 * K, cy, 23 * K, 2 * K, RGB(150, 180, 255), 200);
        float nw = gfx_text_w("N", 26 * K);
        gfx_text(s, 1590 * K - nw * .5f, cy - gfx_text_lineh(26 * K) * .5f, "N", 26 * K, RGB(255, 255, 255), 255);
        gfx_circle(s, 1606 * K, cy + 17 * K, 6 * K, RGB(80, 220, 120), 255, NULL);
        time_t now = time(NULL);
        struct tm *tmv = localtime(&now);
        if (tmv && tmv->tm_year > 100) {
            char clk[16];
            snprintf(clk, sizeof clk, "%02d:%02d", tmv->tm_hour, tmv->tm_min);
            gfx_text(s, W - 82 * K - gfx_text_w(clk, 30 * K), 44 * K, clk, 30 * K, RGB(255, 255, 255), 245);
        }
    }

    /* chips de la Biblioteca (solo ahí) */
    if (a->section == 3) {
        float cx = 90 * K, cy = 90 * K, ch = 30 * K;
        for (int c = 0; c < 3; c++) {
            char lab[64];
            snprintf(lab, sizeof lab, "%s  %d", CHIP_NAME[c], a->chip_count[c]);
            float cw = gfx_text_w(lab, 17 * K) + 30 * K;
            int sel = (c == a->chip);
            gfx_rrect(s, cx, cy, cw, ch, ch * .5f, sel ? RGB(240, 246, 255) : RGB(10, 14, 30), sel ? 245 : 150);
            if (sel && a->on_chips) gfx_rrect_ring(s, cx - 3 * K, cy - 3 * K, cw + 6 * K, ch + 6 * K, ch * .5f + 3 * K, 2.5f * K, RGB(255, 255, 255), 255);
            gfx_text(s, cx + 15 * K, cy + (ch - gfx_text_lineh(17 * K)) * .5f, lab, 17 * K, sel ? RGB(10, 24, 70) : RGB(225, 232, 250), 255);
            cx += cw + 12 * K;
        }
    }

    if (n > 0) {
        /* fila de cuadraditos: el seleccionado es más grande, los anteriores asoman por la izquierda */
        float xs[MAX_ITEMS], ws[MAX_ITEMS], x = 0, g = 11 * K;
        for (int i = 0; i < n; i++) { ws[i] = (107.f + 65.f * a->grow[i]) * K; xs[i] = x; x += ws[i] + g; }
        int i0 = (int)floorf(a->scroll);
        if (i0 < 0) i0 = 0;
        if (i0 > n - 1) i0 = n - 1;
        float f = a->scroll - i0;
        float ax = xs[i0] + (i0 + 1 < n ? (xs[i0 + 1] - xs[i0]) * f : 0.f);
        float off = (1.f - ease) * 80 * K * a->sec_dir, ytop = 125 * K;
        for (int pass = 0; pass < 2; pass++)
            for (int i = 0; i < n; i++) {
                if ((pass == 1) != (i == a->sel)) continue;
                float cx = xs[i] - ax + 169 * K + off;
                if (cx > W || cx + ws[i] < 0) continue;
                draw_card(a, a->view[i], cx, ytop, ws[i], a->grow[i], ga, accent);
            }

        /* etiqueta bajo la fila: insignia + nombre (+ candado si no está instalado) */
        {
            float lx = (169 + 172 + 15) * K, ly = 262 * K, bh = 32 * K;
            const char *badge = cur->kind == KIND_GAME ? "PS3" : (cur->kind == KIND_MEDIA ? "MEDIA" : "APP");
            float bw = gfx_text_w(badge, 21 * K) + 24 * K;
            gfx_rrect(s, lx, ly - bh * .5f, bw, bh, 7 * K, RGB(0, 0, 0), 60 * ga / 255);
            gfx_rrect_ring(s, lx, ly - bh * .5f, bw, bh, 7 * K, 2 * K, RGB(235, 240, 255), 235 * ga / 255);
            gfx_text(s, lx + 12 * K, ly - gfx_text_lineh(21 * K) * .5f, badge, 21 * K, RGB(255, 255, 255), 255 * ga / 255);
            char nm[80];
            gfx_text_fit(cur->name, 27 * K, 900 * K, nm, sizeof nm);
            gfx_text(s, lx + bw + 14 * K, ly - gfx_text_lineh(27 * K) * .5f, nm, 27 * K, RGB(255, 255, 255), 255 * ga / 255);
            if (!cur->available) draw_lock(s, lx + bw + 28 * K + gfx_text_w(nm, 27 * K), ly - 10 * K, K, RGB(255, 255, 255), 235 * ga / 255);
        }

        /* título, descripción y botones (abajo a la izquierda) */
        {
            float tx = 169 * K;
            char nm[80];
            gfx_text_fit(cur->name, 76 * K, 1150 * K, nm, sizeof nm);
            gfx_text(s, tx + 3 * K, 622 * K + 3 * K, nm, 76 * K, RGB(0, 0, 0), 90 * ga / 255);
            gfx_text(s, tx, 622 * K, nm, 76 * K, RGB(255, 255, 255), 255 * ga / 255);
            gfx_text_wrap(s, tx, 724 * K, 1050 * K, cur->desc, 24 * K, RGB(236, 240, 252), 235 * ga / 255, 1.25f, 2);
            float by = 844 * K, bh = 71 * K, bw = 334 * K;
            const char *lab = !cur->available ? "No instalado" : (cur->kind == KIND_MEDIA ? "Abrir" : "Iniciar");
            gfx_rrect(s, tx, by, bw, bh, bh * .5f, RGB(255, 255, 255), 52 * ga / 255);
            gfx_rrect_ring(s, tx, by, bw, bh, bh * .5f, 1.5f * K, RGB(255, 255, 255), 90 * ga / 255);
            float lw = gfx_text_w(lab, 28 * K);
            gfx_text(s, tx + (bw - lw) * .5f, by + (bh - gfx_text_lineh(28 * K)) * .5f, lab, 28 * K, RGB(255, 255, 255), 255 * ga / 255);
            float dx = tx + bw + 18 * K;
            gfx_circle(s, dx + bh * .5f, by + bh * .5f, bh * .5f, RGB(255, 255, 255), 52 * ga / 255, NULL);
            gfx_circle_ring(s, dx + bh * .5f, by + bh * .5f, bh * .5f, 1.5f * K, RGB(255, 255, 255), 90 * ga / 255);
            for (int k = -1; k <= 1; k++) gfx_circle(s, dx + bh * .5f + k * 14 * K, by + bh * .5f, 3.6f * K, RGB(255, 255, 255), 245 * ga / 255, NULL);
            if (cur->favorite) gfx_star(s, tx + gfx_text_w(nm, 76 * K) + 44 * K, 622 * K + 46 * K, 20 * K, RGB(255, 208, 84), 245 * ga / 255);
        }

        /* carátula pequeña a la derecha + etiquetas */
        {
            int cw = (int)(296 * K);
            float cx = 1453 * K, cy = 500 * K;
            Sprite *cv = get_sprite(a, a->view[a->sel], cw);
            gfx_rrect(s, cx - 6 * K, cy + 8 * K, cw + 12 * K, cw + 12 * K, 0.085f * cw + 6 * K, RGB(0, 0, 10), 70 * ga / 255);
            if (cv) gfx_blit_mask(s, cv->px, cv->mask, cw, cw, (int)cx, (int)cy, ga);
            const char *c1 = cur->kind == KIND_GAME ? "Juego" : (cur->kind == KIND_MEDIA ? "Multimedia" : "Aplicación");
            draw_chip(s, K, cx, 866 * K, 53 * K, c1, 22 * K, ga);
            const char *c2 = cur->available ? (cur->detected ? "Detectado" : "Listo") : "No instalado";
            draw_chip(s, K, cx + gfx_text_w(c1, 22 * K) + 53 * K * .9f + 14 * K, 866 * K, 53 * K, c2, 22 * K, ga);
        }
    } else {
        const char *m = a->section == 3 && a->chip == 2 ? "Aún no tienes favoritos. Pulsa Triángulo sobre un elemento para añadirlo."
                                                        : "No hay elementos en esta sección.";
        gfx_text(s, 169 * K, 520 * K, m, 34 * K, RGB(230, 236, 252), 230);
    }

    /* tres paneles inferiores, asomando por abajo como en la consola */
    {
        float py = 984 * K, ph = H - py + 40 * K;
        float px[3] = { 169 * K, 709 * K, 1247 * K }, pw[3] = { 506 * K, 506 * K, 503 * K };
        char l2[3][96];
        snprintf(l2[0], sizeof l2[0], "%s", cur ? cur->tag : "Sin selección");
        snprintf(l2[1], sizeof l2[1], "%d guardados", a->lib.nfavs);
        snprintf(l2[2], sizeof l2[2], "X Iniciar   Triángulo Favorito   L1 R1 Sección");
        const char *l1[3] = { "Información", "Favoritos", "Controles" };
        for (int i = 0; i < 3; i++) {
            gfx_rrect(s, px[i], py, pw[i], ph, 20 * K, RGB(14, 18, 32), 232 * ga / 255);
            gfx_circle(s, px[i] + 34 * K, py + 33 * K, 9 * K, RGB(255, 255, 255), 225 * ga / 255, NULL);
            gfx_text(s, px[i] + 56 * K, py + 17 * K, l1[i], 24 * K, RGB(255, 255, 255), 250 * ga / 255);
            char fit[100];
            gfx_text_fit(l2[i], 21 * K, pw[i] - 56 * K, fit, sizeof fit);
            gfx_text(s, px[i] + 28 * K, py + 52 * K, fit, 21 * K, RGB(190, 200, 224), 225 * ga / 255);
        }
    }

    /* aviso (entre los botones y los paneles) */
    if (a->toast_t > 0) {
        float al = clampf(a->toast_t / 0.4f, 0.f, 1.f);
        float sz = 26 * K, tw = gfx_text_w(a->toast, sz), bw = tw + 64 * K, bh = 52 * K;
        float bx = (W - bw) * .5f, by = 926 * K;
        gfx_rrect(s, bx, by, bw, bh, bh * .5f, a->toast_err ? RGB(70, 34, 20) : RGB(12, 24, 60), (int)(240 * al));
        gfx_rrect_ring(s, bx, by, bw, bh, bh * .5f, 2 * K, a->toast_err ? RGB(255, 190, 110) : RGB(150, 190, 255), (int)(230 * al));
        gfx_text(s, bx + 32 * K, by + (bh - gfx_text_lineh(sz)) * .5f, a->toast, sz, RGB(255, 255, 255), (int)(255 * al));
    }
    if (a->launching) gfx_rect(s, 0, 0, W, H, RGB(2, 6, 20), imin(170, (int)(a->launch_t * 260)));
}

int app_frame(App *a, unsigned padraw, float dt)
{
    a->frame_no++;
    pad_update(&a->pad, padraw, dt);
    update(a, dt);
    if (!a->dirty) return 0;           /* nada cambió: el framebuffer sigue siendo válido */
    a->dirty = 0;
    draw_frame(a);
    return 1;
}
