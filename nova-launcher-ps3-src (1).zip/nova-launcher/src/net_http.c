/* Cliente HTTP mínimo hacia webMAN MOD en la propia consola (127.0.0.1).
 * Usa sockets BSD. En PS3 hay que llamar a netInitialize() antes (lo hace
 * ps3/main_ps3.c). VERIFICAR contra tu PSL1GHT: ver docs/BUILD.md. */
#include "platform.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

int plat_http_get(const char *path, char *err, int errlen)
{
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) { snprintf(err, errlen, "No se pudo crear el socket"); return -1; }

#ifndef PLATFORM_PS3
    struct timeval tv = { 2, 0 };
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
    setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &tv, sizeof tv);
#endif

    struct sockaddr_in a;
    memset(&a, 0, sizeof a);
    a.sin_family = AF_INET;
    a.sin_port = htons(WM_PORT);
    a.sin_addr.s_addr = inet_addr("127.0.0.1");
    if (connect(fd, (struct sockaddr *)&a, sizeof a) < 0) {
        close(fd);
        snprintf(err, errlen, "webMAN MOD no responde (127.0.0.1:%d)", WM_PORT);
        return -1;
    }

    char req[800];
    int n = snprintf(req, sizeof req,
                     "GET %s HTTP/1.0\r\nHost: 127.0.0.1\r\nUser-Agent: NovaLauncher\r\nConnection: close\r\n\r\n",
                     path);
    int sent = 0;
    while (sent < n) {
        int r = (int)send(fd, req + sent, n - sent, 0);
        if (r <= 0) { close(fd); snprintf(err, errlen, "Error enviando la petición"); return -1; }
        sent += r;
    }

    /* webMAN puede cerrar la conexión sin respuesta al montar/arrancar: eso cuenta como éxito. */
    char resp[64];
    memset(resp, 0, sizeof resp);
    int r = (int)recv(fd, resp, sizeof resp - 1, 0);
    close(fd);
    if (r >= 12 && !strncmp(resp, "HTTP/1.", 7)) {
        int code = 0;
        sscanf(resp + 9, "%d", &code);
        if (code >= 400) { snprintf(err, errlen, "webMAN MOD devolvió HTTP %d", code); return -1; }
    }
    return 0;
}
