#include "gfx.h"
#include "font.h"
#include <stdio.h>
#include <math.h>
#include <string.h>

static inline float clampf(float v, float lo, float hi) { return v < lo ? lo : (v > hi ? hi : v); }
static inline int clampi(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

uint32_t gfx_hsv(float h, float s, float v)
{
    h = fmodf(h, 360.f);
    if (h < 0) h += 360.f;
    float c = v * s, hp = h / 60.f;
    float x = c * (1.f - fabsf(fmodf(hp, 2.f) - 1.f));
    float r = 0, g = 0, b = 0;
    if (hp < 1) { r = c; g = x; }
    else if (hp < 2) { r = x; g = c; }
    else if (hp < 3) { g = c; b = x; }
    else if (hp < 4) { g = x; b = c; }
    else if (hp < 5) { r = x; b = c; }
    else { r = c; b = x; }
    float m = v - c;
    return RGB((int)((r + m) * 255.f + .5f), (int)((g + m) * 255.f + .5f), (int)((b + m) * 255.f + .5f));
}

uint32_t gfx_mix(uint32_t a, uint32_t b, float t)
{
    t = clampf(t, 0.f, 1.f);
    int r = (int)(((a >> 16) & 255) * (1 - t) + ((b >> 16) & 255) * t);
    int g = (int)(((a >> 8) & 255) * (1 - t) + ((b >> 8) & 255) * t);
    int bl = (int)((a & 255) * (1 - t) + (b & 255) * t);
    return RGB(r, g, bl);
}

void gfx_rect(Surf *s, int x, int y, int w, int h, uint32_t c, int a)
{
    int x0 = clampi(x, 0, s->w), x1 = clampi(x + w, 0, s->w);
    int y0 = clampi(y, 0, s->h), y1 = clampi(y + h, 0, s->h);
    for (int j = y0; j < y1; j++)
        for (int i = x0; i < x1; i++) gfx_blend(s, i, j, c, a);
}

/* Distancia con signo a un rectángulo redondeado (negativa dentro). */
static inline float sd_rr(float px, float py, float x, float y, float w, float h, float r)
{
    float hw = w * .5f, hh = h * .5f;
    float qx = fabsf(px - (x + hw)) - (hw - r);
    float qy = fabsf(py - (y + hh)) - (hh - r);
    float ox = qx > 0 ? qx : 0, oy = qy > 0 ? qy : 0;
    float m = qx > qy ? qx : qy;
    if (m > 0) m = 0;
    return sqrtf(ox * ox + oy * oy) + m - r;
}

static inline float clip_cov(const RR *cl, float px, float py)
{
    if (!cl) return 1.f;
    return clampf(.5f - sd_rr(px, py, cl->x, cl->y, cl->w, cl->h, cl->r), 0.f, 1.f);
}

void gfx_rrect(Surf *s, float x, float y, float w, float h, float r, uint32_t c, int a)
{
    int x0 = clampi((int)floorf(x) - 1, 0, s->w), x1 = clampi((int)ceilf(x + w) + 1, 0, s->w);
    int y0 = clampi((int)floorf(y) - 1, 0, s->h), y1 = clampi((int)ceilf(y + h) + 1, 0, s->h);
    for (int j = y0; j < y1; j++)
        for (int i = x0; i < x1; i++) {
            float cov = clampf(.5f - sd_rr(i + .5f, j + .5f, x, y, w, h, r), 0.f, 1.f);
            if (cov > 0) gfx_blend(s, i, j, c, (int)(a * cov));
        }
}

void gfx_rrect_grad(Surf *s, float x, float y, float w, float h, float r,
                    uint32_t c0, uint32_t c1, int a)
{
    int x0 = clampi((int)floorf(x) - 1, 0, s->w), x1 = clampi((int)ceilf(x + w) + 1, 0, s->w);
    int y0 = clampi((int)floorf(y) - 1, 0, s->h), y1 = clampi((int)ceilf(y + h) + 1, 0, s->h);
    for (int j = y0; j < y1; j++)
        for (int i = x0; i < x1; i++) {
            float cov = clampf(.5f - sd_rr(i + .5f, j + .5f, x, y, w, h, r), 0.f, 1.f);
            if (cov <= 0) continue;
            float t = ((i - x) / w + (j - y) / h) * .5f;
            gfx_blend(s, i, j, gfx_mix(c0, c1, t), (int)(a * cov));
        }
}

void gfx_rrect_vfade(Surf *s, float x, float y, float w, float h, float r,
                     uint32_t c, int a0, int a1, float f0)
{
    int x0 = clampi((int)floorf(x) - 1, 0, s->w), x1 = clampi((int)ceilf(x + w) + 1, 0, s->w);
    int y0 = clampi((int)floorf(y) - 1, 0, s->h), y1 = clampi((int)ceilf(y + h) + 1, 0, s->h);
    for (int j = y0; j < y1; j++) {
        float ty = clampf(((j + .5f - y) / h - f0) / (1.f - f0), 0.f, 1.f);
        float al = a0 + (a1 - a0) * ty;
        if (al <= 0) continue;
        for (int i = x0; i < x1; i++) {
            float cov = clampf(.5f - sd_rr(i + .5f, j + .5f, x, y, w, h, r), 0.f, 1.f);
            if (cov > 0) gfx_blend(s, i, j, c, (int)(al * cov));
        }
    }
}

void gfx_rrect_ring(Surf *s, float x, float y, float w, float h, float r,
                    float thick, uint32_t c, int a)
{
    int x0 = clampi((int)floorf(x) - 2, 0, s->w), x1 = clampi((int)ceilf(x + w) + 2, 0, s->w);
    int y0 = clampi((int)floorf(y) - 2, 0, s->h), y1 = clampi((int)ceilf(y + h) + 2, 0, s->h);
    int band = (int)(r + thick + 3.f);
    for (int j = y0; j < y1; j++) {
        int inner_row = (j > y + band && j < y + h - band);
        int ia = inner_row ? (int)(x + thick + 3.f) : x1;   /* a partir de aquí, saltar hasta ib */
        int ib = inner_row ? (int)(x + w - thick - 3.f) : x1;
        for (int i = x0; i < x1; i++) {
            if (inner_row && i >= ia && i < ib) { i = ib - 1; continue; }
            float d = sd_rr(i + .5f, j + .5f, x, y, w, h, r);
            float cov = clampf(.5f - (fabsf(d + thick * .5f) - thick * .5f), 0.f, 1.f);
            if (cov > 0) gfx_blend(s, i, j, c, (int)(a * cov));
        }
    }
}

void gfx_glow(Surf *s, float x, float y, float w, float h, float r,
              float spread, uint32_t c, int a)
{
    int x0 = clampi((int)floorf(x - spread), 0, s->w), x1 = clampi((int)ceilf(x + w + spread), 0, s->w);
    int y0 = clampi((int)floorf(y - spread), 0, s->h), y1 = clampi((int)ceilf(y + h + spread), 0, s->h);
    int band = (int)(r + 4.f);
    for (int j = y0; j < y1; j++) {
        int inner_row = (j > y + band && j < y + h - band);
        int ia = (int)(x + 3.f), ib = (int)(x + w - 3.f);
        for (int i = x0; i < x1; i++) {
            if (inner_row && i >= ia && i < ib) { i = ib - 1; continue; }
            float d = sd_rr(i + .5f, j + .5f, x, y, w, h, r);
            if (d <= -2.f) continue;
            float t = clampf(1.f - (d > 0 ? d : 0) / spread, 0.f, 1.f);
            int al = (int)(a * t * t);
            if (al > 0) gfx_blend(s, i, j, c, al);
        }
    }
}

void gfx_rrect_mask(uint8_t *m, int w, int h, float r)
{
    for (int j = 0; j < h; j++)
        for (int i = 0; i < w; i++)
            m[j * w + i] = (uint8_t)(255.f * clampf(.5f - sd_rr(i + .5f, j + .5f, 0, 0, (float)w, (float)h, r), 0.f, 1.f));
}

void gfx_blit_mask(Surf *s, const uint32_t *src, const uint8_t *mask, int sw, int sh, int dx, int dy, int a)
{
    for (int j = 0; j < sh; j++) {
        int y = dy + j;
        if (y < 0 || y >= s->h) continue;
        for (int i = 0; i < sw; i++) {
            int x = dx + i;
            if (x < 0 || x >= s->w) continue;
            int al = mask[j * sw + i] * a / 255;
            if (al > 0) gfx_blend(s, x, y, src[j * sw + i], al);
        }
    }
}

void gfx_circle(Surf *s, float cx, float cy, float rad, uint32_t c, int a, const RR *clip)
{
    int x0 = clampi((int)floorf(cx - rad) - 1, 0, s->w), x1 = clampi((int)ceilf(cx + rad) + 1, 0, s->w);
    int y0 = clampi((int)floorf(cy - rad) - 1, 0, s->h), y1 = clampi((int)ceilf(cy + rad) + 1, 0, s->h);
    for (int j = y0; j < y1; j++)
        for (int i = x0; i < x1; i++) {
            float dx = i + .5f - cx, dy = j + .5f - cy;
            float cov = clampf(.5f - (sqrtf(dx * dx + dy * dy) - rad), 0.f, 1.f);
            if (cov <= 0) continue;
            cov *= clip_cov(clip, i + .5f, j + .5f);
            if (cov > 0) gfx_blend(s, i, j, c, (int)(a * cov));
        }
}

void gfx_circle_ring(Surf *s, float cx, float cy, float rad, float thick, uint32_t c, int a)
{
    float o = rad + thick;
    int x0 = clampi((int)floorf(cx - o) - 1, 0, s->w), x1 = clampi((int)ceilf(cx + o) + 1, 0, s->w);
    int y0 = clampi((int)floorf(cy - o) - 1, 0, s->h), y1 = clampi((int)ceilf(cy + o) + 1, 0, s->h);
    for (int j = y0; j < y1; j++)
        for (int i = x0; i < x1; i++) {
            float dx = i + .5f - cx, dy = j + .5f - cy;
            float d = sqrtf(dx * dx + dy * dy) - rad;
            float cov = clampf(.5f - (fabsf(d) - thick * .5f), 0.f, 1.f);
            if (cov > 0) gfx_blend(s, i, j, c, (int)(a * cov));
        }
}

void gfx_radial(Surf *s, float cx, float cy, float rad, uint32_t c, int a)
{
    int x0 = clampi((int)floorf(cx - rad), 0, s->w), x1 = clampi((int)ceilf(cx + rad), 0, s->w);
    int y0 = clampi((int)floorf(cy - rad), 0, s->h), y1 = clampi((int)ceilf(cy + rad), 0, s->h);
    float inv = 1.f / rad;
    for (int j = y0; j < y1; j++)
        for (int i = x0; i < x1; i++) {
            float dx = (i + .5f - cx) * inv, dy = (j + .5f - cy) * inv;
            float d2 = dx * dx + dy * dy;
            if (d2 >= 1.f) continue;
            float t = 1.f - d2;
            int al = (int)(a * t * t);
            if (al > 0) gfx_blend(s, i, j, c, al);
        }
}

void gfx_line(Surf *s, float x0f, float y0f, float x1f, float y1f, float thick,
              uint32_t c, int a, const RR *clip)
{
    float pad = thick * .5f + 2.f;
    float minx = (x0f < x1f ? x0f : x1f) - pad, maxx = (x0f > x1f ? x0f : x1f) + pad;
    float miny = (y0f < y1f ? y0f : y1f) - pad, maxy = (y0f > y1f ? y0f : y1f) + pad;
    int x0 = clampi((int)floorf(minx), 0, s->w), x1 = clampi((int)ceilf(maxx), 0, s->w);
    int y0 = clampi((int)floorf(miny), 0, s->h), y1 = clampi((int)ceilf(maxy), 0, s->h);
    float vx = x1f - x0f, vy = y1f - y0f, len2 = vx * vx + vy * vy;
    for (int j = y0; j < y1; j++)
        for (int i = x0; i < x1; i++) {
            float px = i + .5f - x0f, py = j + .5f - y0f;
            float t = len2 > 0 ? clampf((px * vx + py * vy) / len2, 0.f, 1.f) : 0.f;
            float dx = px - vx * t, dy = py - vy * t;
            float cov = clampf(.5f - (sqrtf(dx * dx + dy * dy) - thick * .5f), 0.f, 1.f);
            if (cov <= 0) continue;
            cov *= clip_cov(clip, i + .5f, j + .5f);
            if (cov > 0) gfx_blend(s, i, j, c, (int)(a * cov));
        }
}

void gfx_star(Surf *s, float cx, float cy, float R, uint32_t c, int a)
{
    float vx[10], vy[10];
    for (int k = 0; k < 10; k++) {
        float ang = -1.5707963f + k * 0.6283185f;
        float rr = (k & 1) ? R * 0.42f : R;
        vx[k] = cx + cosf(ang) * rr;
        vy[k] = cy + sinf(ang) * rr;
    }
    int x0 = clampi((int)floorf(cx - R) - 1, 0, s->w), x1 = clampi((int)ceilf(cx + R) + 1, 0, s->w);
    int y0 = clampi((int)floorf(cy - R) - 1, 0, s->h), y1 = clampi((int)ceilf(cy + R) + 1, 0, s->h);
    /* 2x2 supermuestreo con regla par-impar */
    for (int j = y0; j < y1; j++)
        for (int i = x0; i < x1; i++) {
            int hit = 0;
            for (int sy = 0; sy < 2; sy++)
                for (int sx = 0; sx < 2; sx++) {
                    float px = i + .25f + sx * .5f, py = j + .25f + sy * .5f;
                    int in = 0;
                    for (int k = 0, m = 9; k < 10; m = k++) {
                        if (((vy[k] > py) != (vy[m] > py)) &&
                            (px < (vx[m] - vx[k]) * (py - vy[k]) / (vy[m] - vy[k]) + vx[k]))
                            in = !in;
                    }
                    hit += in;
                }
            if (hit) gfx_blend(s, i, j, c, a * hit / 4);
        }
}

/* ---------------------------------------------------------------- texto */

static int utf8_next(const char **p)
{
    const unsigned char *s = (const unsigned char *)*p;
    int cp = 0;
    if (!*s) return 0;
    if (s[0] < 0x80) { cp = s[0]; *p += 1; }
    else if ((s[0] & 0xE0) == 0xC0 && (s[1] & 0xC0) == 0x80) { cp = ((s[0] & 0x1F) << 6) | (s[1] & 0x3F); *p += 2; }
    else if ((s[0] & 0xF0) == 0xE0 && (s[1] & 0xC0) == 0x80 && (s[2] & 0xC0) == 0x80) {
        cp = ((s[0] & 0x0F) << 12) | ((s[1] & 0x3F) << 6) | (s[2] & 0x3F); *p += 3;
    } else { cp = '?'; *p += 1; }
    return cp;
}

static const FontSize *pick_size(float px)
{
    const FontSize *best = &font_sizes[0];
    float bd = 1e9f;
    for (int i = 0; i < font_nsizes; i++) {
        float d = fabsf(font_sizes[i].px - px);
        if (d < bd) { bd = d; best = &font_sizes[i]; }
    }
    return best;
}

static const FontGlyph *find_glyph(const FontSize *fs, int cp)
{
    int lo = fs->first, hi = fs->first + fs->count - 1;
    while (lo <= hi) {
        int mid = (lo + hi) / 2, c = font_glyphs[mid].cp;
        if (c == cp) return &font_glyphs[mid];
        if (c < cp) lo = mid + 1; else hi = mid - 1;
    }
    return NULL;
}

static inline int bm_at(const uint8_t *bm, int w, int h, int x, int y)
{
    return (x < 0 || y < 0 || x >= w || y >= h) ? 0 : bm[y * w + x];
}

static void draw_glyph(Surf *s, const FontGlyph *g, float sc, float penx, float basey, uint32_t col, int a)
{
    if (!g->w || !g->h) return;
    const uint8_t *bm = font_bitmap + g->off;
    if (fabsf(sc - 1.f) < 0.03f) {
        int ox = (int)floorf(penx + .5f) + g->bx, oy = (int)floorf(basey + .5f) - g->by;
        for (int j = 0; j < g->h; j++)
            for (int i = 0; i < g->w; i++) {
                int v = bm[j * g->w + i];
                if (v) gfx_blend(s, ox + i, oy + j, col, v * a / 255);
            }
        return;
    }
    float dx0 = penx + g->bx * sc, dy0 = basey - g->by * sc;
    int ix0 = (int)floorf(dx0) - 1, iy0 = (int)floorf(dy0) - 1;
    int ix1 = (int)ceilf(dx0 + g->w * sc) + 1, iy1 = (int)ceilf(dy0 + g->h * sc) + 1;
    for (int y = iy0; y < iy1; y++)
        for (int x = ix0; x < ix1; x++) {
            float u = (x + .5f - dx0) / sc - .5f, v = (y + .5f - dy0) / sc - .5f;
            int u0 = (int)floorf(u), v0 = (int)floorf(v);
            float fu = u - u0, fv = v - v0;
            float val = bm_at(bm, g->w, g->h, u0, v0) * (1 - fu) * (1 - fv) +
                        bm_at(bm, g->w, g->h, u0 + 1, v0) * fu * (1 - fv) +
                        bm_at(bm, g->w, g->h, u0, v0 + 1) * (1 - fu) * fv +
                        bm_at(bm, g->w, g->h, u0 + 1, v0 + 1) * fu * fv;
            int al = (int)(val * a / 255.f);
            if (al > 0) gfx_blend(s, x, y, col, al);
        }
}

float gfx_text_w(const char *t, float px)
{
    const FontSize *fs = pick_size(px);
    float sc = px / fs->px, w = 0;
    int cp;
    while ((cp = utf8_next(&t)) != 0) {
        const FontGlyph *g = find_glyph(fs, cp);
        if (!g) g = find_glyph(fs, '?');
        if (g) w += g->adv * sc;
    }
    return w;
}

float gfx_text_lineh(float px)
{
    const FontSize *fs = pick_size(px);
    return fs->lineh * (px / fs->px);
}

void gfx_text(Surf *s, float x, float y, const char *t, float px, uint32_t c, int a)
{
    if (a <= 0) return;
    const FontSize *fs = pick_size(px);
    float sc = px / fs->px, pen = x, base = y + fs->ascent * sc;
    int cp;
    while ((cp = utf8_next(&t)) != 0) {
        const FontGlyph *g = find_glyph(fs, cp);
        if (!g) g = find_glyph(fs, '?');
        if (!g) continue;
        draw_glyph(s, g, sc, pen, base, c, a);
        pen += g->adv * sc;
    }
}

void gfx_text_fit(const char *t, float px, float maxw, char *out, int n)
{
    if (gfx_text_w(t, px) <= maxw) { strncpy(out, t, n - 1); out[n - 1] = 0; return; }
    char tmp[256];
    strncpy(tmp, t, sizeof tmp - 1);
    tmp[sizeof tmp - 1] = 0;
    int len = (int)strlen(tmp);
    while (len > 0) {
        len--;
        while (len > 0 && ((unsigned char)tmp[len] & 0xC0) == 0x80) len--; /* no cortar UTF-8 */
        tmp[len] = 0;
        char cand[272];
        snprintf(cand, sizeof cand, "%s…", tmp);
        if (gfx_text_w(cand, px) <= maxw) { strncpy(out, cand, n - 1); out[n - 1] = 0; return; }
    }
    out[0] = 0;
}

float gfx_text_wrap(Surf *s, float x, float y, float maxw, const char *t, float px,
                    uint32_t c, int a, float line_mult, int max_lines)
{
    float lh = gfx_text_lineh(px) * line_mult;
    char line[256] = "";
    int lines = 0;
    const char *p = t;
    while (*p && lines < max_lines) {
        const char *e = p;
        while (*e && *e != ' ') e++;
        char word[128];
        int wl = (int)(e - p);
        if (wl > 127) wl = 127;
        memcpy(word, p, wl);
        word[wl] = 0;
        char cand[400];
        snprintf(cand, sizeof cand, line[0] ? "%s %s" : "%s%s", line, word);
        if (line[0] && gfx_text_w(cand, px) > maxw) {
            gfx_text(s, x, y + lines * lh, line, px, c, a);
            lines++;
            strncpy(line, word, sizeof line - 1);
        } else {
            strncpy(line, cand, sizeof line - 1);
        }
        line[sizeof line - 1] = 0;
        p = e;
        while (*p == ' ') p++;
    }
    if (line[0] && lines < max_lines) {
        gfx_text(s, x, y + lines * lh, line, px, c, a);
        lines++;
    }
    return lines * lh;
}
