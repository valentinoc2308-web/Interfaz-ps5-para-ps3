#ifndef LAUNCH_H
#define LAUNCH_H
#include "library.h"

/* Construye la petición para webMAN MOD (ruta + query, con codificación %XX). */
int launch_build_request(const Item *it, char *out, int n);

/* Envía la petición. Devuelve 0 si webMAN la recibió; si no, texto en err. */
int launch_item(const Item *it, char *err, int errlen);

#endif
