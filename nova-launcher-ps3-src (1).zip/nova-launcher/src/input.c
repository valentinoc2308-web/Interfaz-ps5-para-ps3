#include "input.h"

#define REPEAT_DELAY 0.38f
#define REPEAT_RATE  0.085f

void pad_update(Pad *p, unsigned raw, float dt)
{
    unsigned edges = raw & ~p->prev;
    for (int i = 0; i < 4; i++) {
        unsigned bit = 1u << i;
        if (raw & bit) {
            p->hold[i] += dt;
            if (p->hold[i] > REPEAT_DELAY) {
                p->acc[i] += dt;
                while (p->acc[i] >= REPEAT_RATE) { p->acc[i] -= REPEAT_RATE; edges |= bit; }
            }
        } else {
            p->hold[i] = 0;
            p->acc[i] = 0;
        }
    }
    p->prev = raw;
    p->raw = raw;
    p->pressed = edges;
}

unsigned pad_stick_dirs(int lh, int lv)
{
    unsigned b = 0;
    if (lh < 128 - 70) b |= PB_LEFT;
    if (lh > 128 + 70) b |= PB_RIGHT;
    if (lv < 128 - 70) b |= PB_UP;
    if (lv > 128 + 70) b |= PB_DOWN;
    return b;
}
