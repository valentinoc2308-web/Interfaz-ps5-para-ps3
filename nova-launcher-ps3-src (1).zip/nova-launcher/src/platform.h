#ifndef PLATFORM_H
#define PLATFORM_H
/* Funciones que cada backend (PS3 real o host de pruebas) debe aportar. */

enum { SND_MOVE = 0, SND_SELECT, SND_BACK, SND_SECTION, SND_ERROR, SND_COUNT };

/* Reproduce un sonido de navegación (puede ser no-op). */
void plat_sound(int id);

/* GET http://127.0.0.1:<puerto de webMAN><path>. Devuelve 0 si webMAN respondió
 * sin error HTTP; si no, deja un texto en err. Implementado en src/net_http.c. */
int plat_http_get(const char *path, char *err, int errlen);

#ifndef PS3_ROOT
#define PS3_ROOT ""       /* En la consola las rutas son absolutas (/dev_hdd0/...). */
#endif

#ifndef WM_PORT
#define WM_PORT 80        /* Puerto HTTP de webMAN MOD. */
#endif

#endif
