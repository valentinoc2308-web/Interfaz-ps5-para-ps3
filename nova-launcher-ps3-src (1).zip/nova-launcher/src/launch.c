#include "launch.h"
#include "platform.h"
#include <stdio.h>
#include <string.h>

/* Codifica en %XX todo salvo caracteres seguros para ruta/query. */
static int enc(const char *in, char *out, int n)
{
    static const char hex[] = "0123456789ABCDEF";
    int o = 0;
    for (const unsigned char *p = (const unsigned char *)in; *p; p++) {
        int safe = (*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') || (*p >= '0' && *p <= '9') ||
                   strchr("-_.~/:?=&$%", *p) != NULL;
        if (safe) { if (o + 1 >= n) return -1; out[o++] = (char)*p; }
        else { if (o + 3 >= n) return -1; out[o++] = '%'; out[o++] = hex[*p >> 4]; out[o++] = hex[*p & 15]; }
    }
    out[o] = 0;
    return o;
}

int launch_build_request(const Item *it, char *out, int n)
{
    char e[480];
    if (enc(it->arg, e, sizeof e) < 0) return -1;
    switch (it->act) {
    case ACT_PLAY_PATH:    return snprintf(out, n, "/play.ps3%s", e);
    case ACT_PLAY_QUERY:   return snprintf(out, n, "/play.ps3?%s", e);
    case ACT_BROWSER_URL:  return snprintf(out, n, "/browser.ps3?%s", e);
    case ACT_BROWSER_PATH: return snprintf(out, n, "/browser.ps3%s", e);
    }
    return -1;
}

int launch_item(const Item *it, char *err, int errlen)
{
    char req[600];
    if (launch_build_request(it, req, sizeof req) < 0) {
        snprintf(err, errlen, "Ruta demasiado larga");
        return -1;
    }
    return plat_http_get(req, err, errlen);
}
