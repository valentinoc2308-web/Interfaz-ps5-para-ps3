/* Catálogo, detección de juegos instalados y persistencia.
 * IMPORTANTE: todo el acceso a /dev_hdd0 es de SOLO LECTURA, salvo el fichero
 * de configuración propio (USRDIR de este launcher). Nunca se abre, lista ni
 * modifica savedata. */
#include "library.h"
#include "platform.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <dirent.h>
#include <sys/stat.h>

#define OWN_ID      "PS5LNCH00"
#define CONFIG_PATH PS3_ROOT "/dev_hdd0/game/" OWN_ID "/USRDIR/config.txt"

/* ------------------------------------------------------------ PARAM.SFO */

static unsigned le16(const unsigned char *p) { return p[0] | (p[1] << 8); }
static unsigned le32(const unsigned char *p) { return p[0] | (p[1] << 8) | (p[2] << 16) | ((unsigned)p[3] << 24); }

int sfo_read(const char *path, char *title, int tn, char *titleid, int idn)
{
    static unsigned char buf[32768];
    FILE *f = fopen(path, "rb");
    if (!f) return 0;
    size_t n = fread(buf, 1, sizeof buf, f);
    fclose(f);
    if (n < 20 || memcmp(buf, "\0PSF", 4) != 0) return 0;
    unsigned kt = le32(buf + 8), dt = le32(buf + 12), cnt = le32(buf + 16);
    int found = 0;
    if (title && tn) title[0] = 0;
    if (titleid && idn) titleid[0] = 0;
    for (unsigned i = 0; i < cnt && i < 64; i++) {
        const unsigned char *e = buf + 20 + i * 16;
        if (e + 16 > buf + n) break;
        unsigned ko = le16(e), len = le32(e + 4), dof = le32(e + 12);
        if (kt + ko >= n || dt + dof >= n) continue;
        const char *key = (const char *)buf + kt + ko;
        const char *dat = (const char *)buf + dt + dof;
        unsigned avail = (unsigned)(n - (dt + dof));
        if (len > avail) len = avail;
        if (!strcmp(key, "TITLE") && title && tn) {
            snprintf(title, tn, "%.*s", (int)len, dat);
            for (char *c = title; *c; c++) if (*c == '\n' || *c == '\r') *c = ' ';
            found = title[0] != 0;
        } else if (!strcmp(key, "TITLE_ID") && titleid && idn) {
            snprintf(titleid, idn, "%.*s", (int)len, dat);
        }
    }
    return found;
}

/* ------------------------------------------------------------- catálogo */

static Item *add_item(Library *l, const char *id, const char *name, const char *desc,
                      const char *tag, const char *mono, const char *match,
                      int kind, int hue, int act, const char *arg, int available)
{
    if (l->n >= MAX_ITEMS) return NULL;
    Item *it = &l->items[l->n++];
    memset(it, 0, sizeof *it);
    snprintf(it->id, sizeof it->id, "%s", id);
    snprintf(it->name, sizeof it->name, "%s", name);
    snprintf(it->desc, sizeof it->desc, "%s", desc);
    snprintf(it->tag, sizeof it->tag, "%s", tag);
    snprintf(it->mono, sizeof it->mono, "%s", mono);
    snprintf(it->match, sizeof it->match, "%s", match);
    snprintf(it->arg, sizeof it->arg, "%s", arg);
    it->kind = kind;
    it->hue = hue;
    it->act = act;
    it->available = available;
    return it;
}

void lib_init(Library *l)
{
    memset(l, 0, sizeof *l);
    l->exit_after = 1;
    l->fx = 1;

    /* JUEGOS — se activan al detectarse en el disco */
    add_item(l, "static:gtav", "GTA V",
             "Acción de mundo abierto en Los Santos. Se monta y arranca con webMAN MOD.",
             "PS3", "V", "GRAND THEFT AUTO V|GTA V|GTAV", KIND_GAME, 214, ACT_PLAY_PATH, "", 0);
    add_item(l, "static:fifa19", "FIFA 19",
             "Simulador de fútbol de EA Sports. Se monta y arranca con webMAN MOD.",
             "PS3", "19", "FIFA 19", KIND_GAME, 150, ACT_PLAY_PATH, "", 0);
    add_item(l, "static:minecraft", "Minecraft",
             "Construye, explora y sobrevive en un mundo de bloques.",
             "PS3", "M", "MINECRAFT", KIND_GAME, 128, ACT_PLAY_PATH, "", 0);

    /* MULTIMEDIA — abre el explorador web de webMAN sobre cada carpeta (alternativa
     * documentada: webMAN no expone un comando para abrir el reproductor del XMB). */
    add_item(l, "static:music", "Música",
             "Explora tu carpeta de música (/dev_hdd0/music) con el explorador de webMAN MOD.",
             "MULTIMEDIA", "Mú", "", KIND_MEDIA, 275, ACT_BROWSER_PATH, "/dev_hdd0/music", 1);
    add_item(l, "static:video", "Vídeos",
             "Explora tu carpeta de vídeos (/dev_hdd0/video) con el explorador de webMAN MOD.",
             "MULTIMEDIA", "Ví", "", KIND_MEDIA, 300, ACT_BROWSER_PATH, "/dev_hdd0/video", 1);
    add_item(l, "static:photo", "Imágenes",
             "Explora tu carpeta de imágenes (/dev_hdd0/photo) con el explorador de webMAN MOD.",
             "MULTIMEDIA", "Im", "", KIND_MEDIA, 250, ACT_BROWSER_PATH, "/dev_hdd0/photo", 1);

    /* APLICACIONES */
    add_item(l, "static:deepplay", "Deep Play",
             "Aplicación instalada en la consola. Se activa cuando se detecta en el disco.",
             "APP", "D", "DEEP PLAY|DEEPPLAY", KIND_APP, 196, ACT_PLAY_QUERY, "", 0);
    add_item(l, "static:multiman", "multiMAN",
             "Gestor de juegos y archivos. Lo abre webMAN MOD por nombre.",
             "APP", "mM", "MULTIMAN|MULTIMAN", KIND_APP, 205, ACT_PLAY_QUERY, "multiman", 1);
    add_item(l, "static:webman", "webMAN MOD",
             "Abre la interfaz web de webMAN MOD en el navegador de la consola.",
             "APP", "wM", "", KIND_APP, 168, ACT_BROWSER_URL, "http://127.0.0.1/", 1);
    add_item(l, "static:browser", "Navegador",
             "Abre el navegador web de la consola.",
             "APP", "N", "", KIND_APP, 222, ACT_BROWSER_URL, "http://www.google.com/", 1);
    add_item(l, "static:settings", "Ajustes",
             "Abre la configuración de webMAN MOD (/setup.ps3).",
             "APP", "A", "", KIND_APP, 240, ACT_BROWSER_URL, "http://127.0.0.1/setup.ps3", 1);
}

/* --------------------------------------------------------------- escaneo */

static void norm_alnum(const char *in, char *out, int n)
{
    int k = 0;
    for (; *in && k < n - 1; in++)
        if (isalnum((unsigned char)*in)) out[k++] = (char)toupper((unsigned char)*in);
    out[k] = 0;
}

/* Compara ignorando mayúsculas, espacios y signos: "FIFA19_X" encaja con "FIFA 19". */
static int match_title(const char *match, const char *title)
{
    if (!match[0]) return 0;
    char up[128], m[96], tk[96];
    norm_alnum(title, up, sizeof up);
    snprintf(m, sizeof m, "%s", match);
    for (char *tok = strtok(m, "|"); tok; tok = strtok(NULL, "|")) {
        norm_alnum(tok, tk, sizeof tk);
        if (tk[0] && strstr(up, tk)) return 1;
    }
    return 0;
}

static int name_cmp(const void *a, const void *b)
{
    return strcasecmp(((const Item *)a)->name, ((const Item *)b)->name);
}

static int hash_hue(const char *s)
{
    unsigned h = 5381;
    while (*s) h = h * 33 + (unsigned char)*s++;
    return 170 + (int)(h % 140);   /* azules, violetas y verdes: coherente con el fondo */
}

static void add_detected(Library *l, const char *title, const char *tid, const char *tag,
                         int kind, int act, const char *arg, const char *desc)
{
    for (int i = 0; i < l->n; i++) {
        Item *s = &l->items[i];
        if (s->detected || !s->match[0] || !match_title(s->match, title)) continue;
        s->detected = 1;
        s->available = 1;
        if (s->kind == KIND_APP && desc && desc[0]) snprintf(s->desc, sizeof s->desc, "%s", desc);
        if (!s->arg[0]) { snprintf(s->arg, sizeof s->arg, "%s", arg); s->act = act; }
        if (tid[0]) snprintf(s->tag, sizeof s->tag, "%s · %s", tag, tid);
        return;
    }
    char id[96], mono[8] = "", t2[40];
    snprintf(id, sizeof id, "path:%s", arg);
    int k = 0;
    for (const char *c = title; *c && k < 2; c++)
        if (isalnum((unsigned char)*c)) mono[k++] = (char)toupper((unsigned char)*c);
    mono[k] = 0;
    if (tid[0]) snprintf(t2, sizeof t2, "%s · %s", tag, tid); else snprintf(t2, sizeof t2, "%s", tag);
    Item *it = add_item(l, id, title, desc, t2, mono, "", kind, hash_hue(title), act, arg, 1);
    if (it) it->detected = 1;
}

static void scan_game_folders(Library *l, const char *dir)
{
    char full[256];
    snprintf(full, sizeof full, "%s%s", PS3_ROOT, dir);
    DIR *d = opendir(full);
    if (!d) return;
    struct dirent *e;
    while ((e = readdir(d)) != NULL) {
        if (e->d_name[0] == '.' || strlen(e->d_name) > 120) continue; /* evita rutas truncadas */
        char sfo[512], title[64], tid[16], arg[200], desc[200];
        snprintf(sfo, sizeof sfo, "%s/%s/PS3_GAME/PARAM.SFO", full, e->d_name);
        if (!sfo_read(sfo, title, sizeof title, tid, sizeof tid)) {
            snprintf(title, sizeof title, "%s", e->d_name);
            tid[0] = 0;
        }
        snprintf(arg, sizeof arg, "%s/%s", dir, e->d_name);
        snprintf(desc, sizeof desc, "Juego instalado en %s. Se monta y arranca con webMAN MOD.", dir);
        add_detected(l, title, tid, "PS3", KIND_GAME, ACT_PLAY_PATH, arg, desc);
    }
    closedir(d);
}

static void scan_iso_folder(Library *l, const char *dir)
{
    char full[256];
    snprintf(full, sizeof full, "%s%s", PS3_ROOT, dir);
    DIR *d = opendir(full);
    if (!d) return;
    struct dirent *e;
    while ((e = readdir(d)) != NULL) {
        size_t n = strlen(e->d_name);
        if (n > 120 || n < 5 || strcasecmp(e->d_name + n - 4, ".iso") != 0) continue;
        char title[64], arg[200];
        snprintf(title, sizeof title, "%.*s", (int)(n - 4), e->d_name);
        snprintf(arg, sizeof arg, "%s/%s", dir, e->d_name);
        add_detected(l, title, "", "PS3 ISO", KIND_GAME, ACT_PLAY_PATH, arg,
                     "Imagen ISO en PS3ISO. Se monta y arranca con webMAN MOD.");
    }
    closedir(d);
}

static void scan_installed_apps(Library *l)
{
    char full[256];
    snprintf(full, sizeof full, "%s/dev_hdd0/game", PS3_ROOT);
    DIR *d = opendir(full);
    if (!d) return;
    struct dirent *e;
    while ((e = readdir(d)) != NULL) {
        if (e->d_name[0] == '.' || !strcmp(e->d_name, OWN_ID) || strlen(e->d_name) > 15) continue; /* IDs de contenido: 9 caracteres */
        char sfo[512], eboot[512], title[64], tid[16];
        struct stat st;
        snprintf(eboot, sizeof eboot, "%s/%s/USRDIR/EBOOT.BIN", full, e->d_name);
        if (stat(eboot, &st) != 0) continue;                 /* solo programas lanzables */
        snprintf(sfo, sizeof sfo, "%s/%s/PARAM.SFO", full, e->d_name);
        if (!sfo_read(sfo, title, sizeof title, tid, sizeof tid)) continue;
        snprintf(tid, sizeof tid, "%s", e->d_name);
        int psn = (tid[0] == 'N' && tid[1] == 'P');
        char desc[200];
        snprintf(desc, sizeof desc, psn ? "Título instalado desde PSN (ID %s)." :
                 "Aplicación instalada en la consola (ID %s).", tid);
        add_detected(l, title, tid, psn ? "PSN" : "APP", psn ? KIND_GAME : KIND_APP,
                     ACT_PLAY_QUERY, tid, desc);
    }
    closedir(d);
}

void lib_scan(Library *l)
{
    int first_dyn = l->n;
    scan_game_folders(l, "/dev_hdd0/GAMES");
    scan_game_folders(l, "/dev_hdd0/GAMEZ");
    scan_iso_folder(l, "/dev_hdd0/PS3ISO");
    scan_installed_apps(l);
    if (l->n > first_dyn) qsort(&l->items[first_dyn], l->n - first_dyn, sizeof(Item), name_cmp);
    lib_sync_favs(l);
}

/* ------------------------------------------------------------- favoritos */

void lib_sync_favs(Library *l)
{
    for (int i = 0; i < l->n; i++) {
        l->items[i].favorite = 0;
        for (int f = 0; f < l->nfavs; f++)
            if (!strcmp(l->favs[f], l->items[i].id)) { l->items[i].favorite = 1; break; }
    }
}

void lib_toggle_fav(Library *l, int idx)
{
    if (idx < 0 || idx >= l->n) return;
    const char *id = l->items[idx].id;
    for (int f = 0; f < l->nfavs; f++)
        if (!strcmp(l->favs[f], id)) {
            for (int k = f; k < l->nfavs - 1; k++) memcpy(l->favs[k], l->favs[k + 1], sizeof l->favs[k]);
            l->nfavs--;
            lib_sync_favs(l);
            return;
        }
    if (l->nfavs < MAX_FAVS) { strncpy(l->favs[l->nfavs], id, sizeof l->favs[0] - 1); l->favs[l->nfavs][sizeof l->favs[0] - 1] = 0; l->nfavs++; }
    lib_sync_favs(l);
}

/* ----------------------------------------------------------- configuración */

void lib_load_config(Library *l)
{
    FILE *f = fopen(CONFIG_PATH, "r");
    if (!f) return;
    char line[160];
    while (fgets(line, sizeof line, f)) {
        line[strcspn(line, "\r\n")] = 0;
        char *eq = strchr(line, '=');
        if (!eq) continue;
        *eq = 0;
        const char *k = line, *v = eq + 1;
        if (!strcmp(k, "section")) { int s = atoi(v); l->section = (s >= 0 && s < 4) ? s : 0; }
        else if (!strcmp(k, "exit_after")) l->exit_after = atoi(v) != 0;
        else if (!strcmp(k, "fx")) l->fx = atoi(v) != 0;
        else if (!strcmp(k, "fav") && l->nfavs < MAX_FAVS && v[0])
            snprintf(l->favs[l->nfavs++], sizeof l->favs[0], "%s", v);
    }
    fclose(f);
    lib_sync_favs(l);
}

void lib_save_config(const Library *l)
{
    FILE *f = fopen(CONFIG_PATH, "w");
    if (!f) return;
    fprintf(f, "section=%d\nexit_after=%d\nfx=%d\n", l->section, l->exit_after, l->fx);
    for (int i = 0; i < l->nfavs; i++) fprintf(f, "fav=%s\n", l->favs[i]);
    fclose(f);
}
