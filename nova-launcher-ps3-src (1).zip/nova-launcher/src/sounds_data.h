#ifndef SOUNDS_DATA_H
#define SOUNDS_DATA_H
#include <stdint.h>
#include "platform.h"

#define SOUND_COUNT SND_COUNT
typedef struct { const int16_t *pcm; int n; } SoundData;   /* mono, 48 kHz */
extern const SoundData sound_table[SOUND_COUNT];
#endif
