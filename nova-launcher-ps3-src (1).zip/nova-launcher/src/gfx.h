#ifndef GFX_H
#define GFX_H
/* Motor gráfico por software. Píxeles XRGB (0x00RRGGBB) en memoria principal.
 * No depende de ninguna API de la consola: el backend solo copia el Surf al
 * framebuffer. Todas las coordenadas son float y los bordes salen suavizados. */
#include <stdint.h>

typedef struct { int w, h; uint32_t *px; } Surf;
typedef struct { float x, y, w, h, r; } RR; /* rectángulo redondeado (clip) */

#define RGB(r, g, b) ((uint32_t)((((r) & 255) << 16) | (((g) & 255) << 8) | ((b) & 255)))

static inline void gfx_blend(Surf *s, int x, int y, uint32_t c, int a)
{
    if (a <= 0 || x < 0 || y < 0 || x >= s->w || y >= s->h) return;
    if (a > 255) a = 255;
    uint32_t *p = &s->px[y * s->w + x];
    uint32_t d = *p;
    int dr = (d >> 16) & 255, dg = (d >> 8) & 255, db = d & 255;
    int sr = (c >> 16) & 255, sg = (c >> 8) & 255, sb = c & 255;
    int k = a + 1;
    dr += ((sr - dr) * k) >> 8;
    dg += ((sg - dg) * k) >> 8;
    db += ((sb - db) * k) >> 8;
    *p = (uint32_t)((dr << 16) | (dg << 8) | db);
}

uint32_t gfx_hsv(float h, float s, float v);
uint32_t gfx_mix(uint32_t a, uint32_t b, float t);

void gfx_rect(Surf *s, int x, int y, int w, int h, uint32_t c, int a);
void gfx_rrect(Surf *s, float x, float y, float w, float h, float r, uint32_t c, int a);
void gfx_rrect_grad(Surf *s, float x, float y, float w, float h, float r,
                    uint32_t c0, uint32_t c1, int a);
/* Relleno con alfa variable en vertical: a0 hasta la fracción f0, luego sube a a1 en el borde inferior. */
void gfx_rrect_vfade(Surf *s, float x, float y, float w, float h, float r,
                     uint32_t c, int a0, int a1, float f0);
void gfx_rrect_ring(Surf *s, float x, float y, float w, float h, float r,
                    float thick, uint32_t c, int a);
void gfx_glow(Surf *s, float x, float y, float w, float h, float r,
              float spread, uint32_t c, int a);
/* Máscara de cobertura (w*h bytes) de un rectángulo redondeado, y copia con máscara y alfa global. */
void gfx_rrect_mask(uint8_t *m, int w, int h, float r);
void gfx_blit_mask(Surf *s, const uint32_t *src, const uint8_t *mask, int sw, int sh, int dx, int dy, int a);
void gfx_circle(Surf *s, float cx, float cy, float rad, uint32_t c, int a, const RR *clip);
void gfx_circle_ring(Surf *s, float cx, float cy, float rad, float thick, uint32_t c, int a);
void gfx_radial(Surf *s, float cx, float cy, float rad, uint32_t c, int a);
void gfx_line(Surf *s, float x0, float y0, float x1, float y1, float thick,
              uint32_t c, int a, const RR *clip);
void gfx_star(Surf *s, float cx, float cy, float R, uint32_t c, int a);

float gfx_text_w(const char *t, float px);
float gfx_text_lineh(float px);
void gfx_text(Surf *s, float x, float y, const char *t, float px, uint32_t c, int a);
/* Ajusta el texto a maxw añadiendo "…" si hace falta. out debe tener n bytes. */
void gfx_text_fit(const char *t, float px, float maxw, char *out, int n);
/* Texto con saltos de línea por palabras. Devuelve el alto usado. */
float gfx_text_wrap(Surf *s, float x, float y, float maxw, const char *t, float px,
                    uint32_t c, int a, float line_mult, int max_lines);

#endif
