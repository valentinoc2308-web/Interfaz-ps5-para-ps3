/* Sonidos de navegación en PS3 con la librería de audio de PSL1GHT.
 *
 * SIN VERIFICAR: escrito según el patrón de samples/audio de PSL1GHT, sin
 * compilar. Si falla la compilación o suena mal, construye con AUDIO=0
 * (usa audio_stub.c) y el launcher funciona en silencio.
 *
 * Mezcla muy simple: voces de un disparo (5 sonidos) sumadas en bloques
 * estéreo float de 256 muestras a 48 kHz, rellenados cada fotograma.
 */
#include <stdint.h>
#include <string.h>
#include <audio/audio.h>
#include "../src/platform.h"
#include "../src/sounds_data.h"

#define BLOCK_SAMPLES 256           /* AUDIO_BLOCK_SAMPLES */
#define NUM_BLOCKS    8             /* AUDIO_BLOCK_8 */

static u32 g_port;
static audioPortConfig g_cfg;
static int g_ok;
static int g_write_block;           /* siguiente bloque a rellenar */
static struct { const int16_t *pcm; int n, pos; } voice[4];

void plat_sound(int id)
{
    if (!g_ok || id < 0 || id >= SOUND_COUNT) return;
    for (int i = 0; i < 4; i++)
        if (!voice[i].pcm || voice[i].pos >= voice[i].n) {
            voice[i].pcm = sound_table[id].pcm;
            voice[i].n = sound_table[id].n;
            voice[i].pos = 0;
            return;
        }
}

static void fill_block(float *out)
{
    for (int i = 0; i < BLOCK_SAMPLES; i++) {
        float m = 0;
        for (int v = 0; v < 4; v++)
            if (voice[v].pcm && voice[v].pos < voice[v].n) m += voice[v].pcm[voice[v].pos++] * (1.f / 32768.f);
        if (m > 1.f) m = 1.f; else if (m < -1.f) m = -1.f;
        out[i * 2] = out[i * 2 + 1] = m * 0.8f;
    }
}

/* Se llama una vez por fotograma desde main (a través de audio_pump). */
void audio_pump(void)
{
    if (!g_ok) return;
    u32 read_block = *(volatile u32 *)(uintptr_t)g_cfg.readIndex;   /* VERIFICAR: tipo/campo readIndex */
    float *base = (float *)(uintptr_t)g_cfg.audioDataStart;         /* VERIFICAR: campo audioDataStart */
    while (g_write_block != (int)((read_block + NUM_BLOCKS - 1) % NUM_BLOCKS)) {
        fill_block(base + g_write_block * BLOCK_SAMPLES * 2);
        g_write_block = (g_write_block + 1) % NUM_BLOCKS;
    }
}

void audio_init(void)
{
    if (audioInit() != 0) return;                                    /* VERIFICAR */
    audioPortParam p;
    memset(&p, 0, sizeof p);
    p.numChannels = AUDIO_PORT_2CH;                                  /* VERIFICAR nombres de enum */
    p.numBlocks = AUDIO_BLOCK_8;
    p.attr = 0;
    p.level = 1.0f;
    if (audioPortOpen(&p, &g_port) != 0) return;
    if (audioGetPortConfig(g_port, &g_cfg) != 0) return;
    memset((void *)(uintptr_t)g_cfg.audioDataStart, 0, sizeof(float) * 2 * BLOCK_SAMPLES * NUM_BLOCKS);
    if (audioPortStart(g_port) != 0) return;
    g_ok = 1;
}

void audio_shutdown(void)
{
    if (!g_ok) return;
    audioPortStop(g_port);
    audioPortClose(g_port);
    audioQuit();
    g_ok = 0;
}
