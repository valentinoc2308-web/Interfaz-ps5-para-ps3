/* Backend NATIVO de PS3 (PSL1GHT). Se compila SOLO con la toolchain de PS3.
 *
 * ESTADO DE VERIFICACIÓN (ver docs/BUILD.md, sección "Primer build"):
 *   [verificado en documentación] ioPadInit/ioPadGetInfo/ioPadGetData, campos
 *       BTN_* y ANA_* de padData.
 *   [patrón estándar de los ejemplos de PSL1GHT, SIN compilar aquí] vídeo/RSX,
 *       sysutil, sockets, proceso. Los puntos exactos están marcados con
 *       "VERIFICAR" para localizarlos rápido si el compilador protesta.
 * Este archivo no se pudo compilar en el entorno de desarrollo (no había
 * toolchain de PS3 ni red para instalarla).
 */
#define PLATFORM_PS3 1

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>
#include <unistd.h>

#include <io/pad.h>
#include <rsx/rsx.h>
#include <sysutil/sysutil.h>
#include <sysutil/video.h>
#include <sys/process.h>
#include <net/net.h>               /* VERIFICAR: netInitialize() */

#include "../src/ui.h"
#include "../src/input.h"
#include "../src/platform.h"

#ifndef RENDER_W
#define RENDER_W 1280               /* 720p por defecto: el software-render es el cuello de botella */
#define RENDER_H 720
#endif

#define CB_SIZE   0x100000
#define HOST_SIZE (32 * 1024 * 1024)

extern void audio_init(void);       /* ps3/audio_ps3.c (o audio_stub.c) */
extern void audio_shutdown(void);
extern void audio_pump(void);

static gcmContextData *g_ctx;
static u32 g_w, g_h;
static void *g_fb[2];
static u32 g_fb_off[2];
static int g_cur;
static volatile int g_quit;

/* ------------------------------------------------------------ sysutil */

static void sysutil_cb(u64 status, u64 param, void *usrdata)
{
    (void)param; (void)usrdata;
    if (status == SYSUTIL_EXIT_GAME) g_quit = 1;          /* botón PS -> "Salir del juego" */
}

/* -------------------------------------------------------------- vídeo
 * Patrón de samples/graphics de PSL1GHT.  VERIFICAR contra el ejemplo
 * "rsxtest" de tu PSL1GHT: firma de rsxInit(), nombres de enums de vídeo. */
static int video_init(void)
{
    void *host = memalign(1024 * 1024, HOST_SIZE);
    if (!host) return -1;
    rsxInit(&g_ctx, CB_SIZE, HOST_SIZE, host);            /* VERIFICAR: firma */
    if (!g_ctx) return -1;

    videoState st;
    if (videoGetState(0, 0, &st) != 0) return -1;
    videoConfiguration vc;
    memset(&vc, 0, sizeof vc);
    vc.resolution = VIDEO_RESOLUTION_720;                 /* VERIFICAR nombre; la consola escala al TV */
    vc.format = VIDEO_BUFFER_FORMAT_XRGB;
    vc.pitch = RENDER_W * 4;
    vc.aspect = VIDEO_ASPECT_AUTO;
    if (videoConfigure(0, &vc, NULL, 0) != 0) return -1;
    g_w = RENDER_W;
    g_h = RENDER_H;

    gcmSetFlipMode(GCM_FLIP_VSYNC);
    for (int i = 0; i < 2; i++) {
        g_fb[i] = rsxMemalign(64, g_w * g_h * 4);
        if (!g_fb[i]) return -1;
        rsxAddressToOffset(g_fb[i], &g_fb_off[i]);
        gcmSetDisplayBuffer(i, g_fb_off[i], g_w * 4, g_w, g_h);
    }
    gcmResetFlipStatus();
    return 0;
}

static void wait_flip(void)
{
    while (gcmGetFlipStatus() != 0) usleep(200);
    gcmResetFlipStatus();
}

static void present(const Surf *s)
{
    wait_flip();
    memcpy(g_fb[g_cur], s->px, (size_t)g_w * g_h * 4);   /* XRGB8888, mismo formato que Surf */
    gcmSetFlip(g_ctx, g_cur);
    rsxFlushBuffer(g_ctx);
    gcmSetWaitFlip(g_ctx);
    g_cur ^= 1;
}

/* --------------------------------------------------------------- mando */

static unsigned read_pad(void)
{
    padInfo info;
    padData d;
    unsigned raw = 0;
    ioPadGetInfo(&info);
    for (int p = 0; p < MAX_PADS && p < 7; p++) {
        if (!info.status[p]) continue;                    /* VERIFICAR: campo "status" de padInfo */
        ioPadGetData(p, &d);
        if (d.BTN_UP) raw |= PB_UP;
        if (d.BTN_DOWN) raw |= PB_DOWN;
        if (d.BTN_LEFT) raw |= PB_LEFT;
        if (d.BTN_RIGHT) raw |= PB_RIGHT;
        if (d.BTN_CROSS) raw |= PB_CROSS;
        if (d.BTN_CIRCLE) raw |= PB_CIRCLE;
        if (d.BTN_TRIANGLE) raw |= PB_TRI;
        if (d.BTN_SQUARE) raw |= PB_SQUARE;
        if (d.BTN_L1) raw |= PB_L1;
        if (d.BTN_R1) raw |= PB_R1;
        if (d.BTN_START) raw |= PB_START;
        if (d.BTN_SELECT) raw |= PB_SELECT;
        raw |= pad_stick_dirs(d.ANA_L_H, d.ANA_L_V);      /* joystick izquierdo */
        break;                                            /* primer mando conectado */
    }
    return raw;
}

/* ---------------------------------------------------------------- main */

int main(void)
{
    netInitialize();                                      /* VERIFICAR: necesario para sockets */
    sysUtilRegisterCallback(SYSUTIL_EVENT_SLOT0, sysutil_cb, NULL);
    ioPadInit(7);

    if (video_init() != 0) return 1;
    audio_init();

    App *app = app_create((int)g_w, (int)g_h);
    if (!app) return 1;

    while (!g_quit && !app_wants_exit(app)) {
        sysUtilCheckCallback();
        app_frame(app, read_pad(), 1.f / 60.f);           /* flip con vsync => ~60 Hz */
        audio_pump();
        present(app_surface(app));
    }

    app_destroy(app);                                     /* el estado ya se guardó al cambiar de sección/favoritos */
    audio_shutdown();
    ioPadEnd();
    sysProcessExit(0);                                    /* VERIFICAR: <sys/process.h> */
    return 0;
}
