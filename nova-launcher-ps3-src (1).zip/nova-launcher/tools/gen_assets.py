#!/usr/bin/env python3
"""Genera los recursos ORIGINALES del launcher (nada de Sony):
  - assets/sounds/*.wav  : 5 sonidos de navegación sintetizados (seno + envolvente)
  - src/sounds_data.c    : los mismos sonidos como arrays int16 mono 48 kHz
  - assets/ICON0.PNG     : icono 320x176 del PKG, dibujado con el mismo estilo azul
Uso: python3 tools/gen_assets.py
"""
import os, wave
import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
SR = 48000


def tone(freqs, dur, vol=0.5, attack=0.004, decay=None, glide=None):
    n = int(SR * dur)
    t = np.arange(n) / SR
    out = np.zeros(n)
    for f, amp in freqs:
        f_t = f if glide is None else f * (1 + glide * t / dur)
        out += amp * np.sin(2 * np.pi * np.cumsum(np.broadcast_to(f_t, t.shape)) / SR)
    env = np.minimum(1, t / attack) * np.exp(-t * (decay if decay else 6.0 / dur))
    out *= env
    out /= max(1e-9, np.max(np.abs(out)))
    # fundido final para evitar clics
    fade = min(200, n // 4)
    out[-fade:] *= np.linspace(1, 0, fade)
    return (out * vol * 32767).astype(np.int16)


SOUNDS = {
    "move":    tone([(1320, 1.0), (1980, 0.25)], 0.070, 0.30, decay=45),
    "select":  np.concatenate([tone([(880, 1.0), (1760, 0.3)], 0.07, 0.42, decay=30),
                               tone([(1320, 1.0), (2640, 0.3)], 0.16, 0.42, decay=16)]),
    "back":    np.concatenate([tone([(988, 1.0)], 0.06, 0.36, decay=34),
                               tone([(660, 1.0)], 0.12, 0.36, decay=18)]),
    "section": tone([(523, 1.0), (784, 0.5), (1047, 0.3)], 0.20, 0.40, decay=14, glide=0.18),
    "error":   np.concatenate([tone([(220, 1.0), (330, 0.3)], 0.09, 0.45, decay=22),
                               np.zeros(int(SR * 0.03), dtype=np.int16),
                               tone([(196, 1.0), (294, 0.3)], 0.14, 0.45, decay=16)]),
}
ORDER = ["move", "select", "back", "section", "error"]   # = enum SND_* en platform.h

os.makedirs(os.path.join(ROOT, "assets", "sounds"), exist_ok=True)
for name in ORDER:
    with wave.open(os.path.join(ROOT, "assets", "sounds", name + ".wav"), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(SOUNDS[name].tobytes())

with open(os.path.join(ROOT, "src", "sounds_data.c"), "w") as f:
    f.write("/* GENERADO por tools/gen_assets.py. Sonidos originales, mono 16 bit 48 kHz. No editar. */\n")
    f.write('#include "sounds_data.h"\n\n')
    for name in ORDER:
        d = SOUNDS[name]
        f.write("static const int16_t snd_%s[%d] = {\n" % (name, len(d)))
        for i in range(0, len(d), 24):
            f.write(",".join(str(int(v)) for v in d[i:i + 24]) + ",\n")
        f.write("};\n")
    f.write("\nconst SoundData sound_table[SOUND_COUNT] = {\n")
    for name in ORDER:
        f.write("    { snd_%s, %d },\n" % (name, len(SOUNDS[name])))
    f.write("};\n")

# --------------------------------------------------------------- ICON0.PNG
W, H = 320, 176
img = Image.new("RGB", (W, H))
px = img.load()
for y in range(H):
    for x in range(W):
        k = y / H
        px[x, y] = (int(6 + 8 * k), int(12 + 30 * k), int(34 + 70 * k))
glow = Image.new("RGB", (W, H), (0, 0, 0))
d = ImageDraw.Draw(glow)
d.ellipse((-60, -90, 190, 130), fill=(60, 110, 255))
d.ellipse((170, 60, 420, 260), fill=(110, 70, 230))
glow = glow.filter(ImageFilter.GaussianBlur(38))
img = Image.blend(img, Image.composite(glow, img, glow.convert("L")), 0.65)
d = ImageDraw.Draw(img)
# cuatro tarjetas estilizadas, la central iluminada
cols = [(70, 150, 250), (90, 220, 160), (150, 110, 240), (70, 190, 230)]
x0 = 30
for i, c in enumerate(cols):
    s = 62 if i == 1 else 46
    y1 = 150
    x1 = x0 + s
    d.rounded_rectangle((x0, y1 - s, x1, y1), radius=9, fill=c)
    if i == 1:
        d.rounded_rectangle((x0 - 3, y1 - s - 3, x1 + 3, y1 + 3), radius=12, outline=(255, 255, 255), width=3)
    x0 = x1 + 16
font = ImageFont.truetype("/usr/share/fonts/opentype/inter/Inter-SemiBold.otf", 22)
d.text((34, 24), "NOVA", font=font, fill=(240, 246, 255))
font2 = ImageFont.truetype("/usr/share/fonts/opentype/inter/Inter-Medium.otf", 13)
d.text((34, 52), "LAUNCHER · PS3", font=font2, fill=(160, 190, 255))
img.save(os.path.join(ROOT, "assets", "ICON0.PNG"))
print("OK: sonidos, src/sounds_data.c e ICON0.PNG generados")
