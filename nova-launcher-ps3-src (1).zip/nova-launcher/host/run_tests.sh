#!/usr/bin/env bash
# Pruebas automáticas en PC: crea una "consola" falsa en disco, levanta un
# webMAN falso que registra peticiones y comprueba detección, lanzamiento,
# favoritos, persistencia, salida y manejo de errores. Salida: PASS/FAIL.
set -u
cd "$(dirname "$0")"
FAKE=$(mktemp -d); PORT=18080; LOG=$FAKE/wm.log
trap 'kill $SRV 2>/dev/null; rm -rf "$FAKE"' EXIT
H=$FAKE/dev_hdd0
mkdir -p $H/GAMES/BLES01807/PS3_GAME $H/GAMES/FIFA19_X $H/GAMES/Minecraft_PS3 $H/PS3ISO \
         $H/game/PS5LNCH00/USRDIR $H/game/DEEPPLAY1/USRDIR $H/game/NPUB30001/USRDIR $H/game/SAVEDATA1
touch "$H/PS3ISO/Gran Turismo 6.iso" $H/game/DEEPPLAY1/USRDIR/EBOOT.BIN $H/game/NPUB30001/USRDIR/EBOOT.BIN
python3 - "$H" <<'EOF'
import struct, sys
def sfo(path, title, tid):
    keys=[("TITLE",title),("TITLE_ID",tid)]; kt=b""; dt=b""; ent=b""
    for k,v in keys:
        ko=len(kt); kt+=k.encode()+b"\0"; do=len(dt); d=v.encode()+b"\0"; dt+=d
        ent+=struct.pack("<HHIII",ko,0x204,len(d),len(d),do)
    while len(kt)%4: kt+=b"\0"
    ks=20+len(ent)
    open(path,"wb").write(b"\0PSF"+struct.pack("<IIII",0x101,ks,ks+len(kt),len(keys))+ent+kt+dt)
H=sys.argv[1]
sfo(H+"/GAMES/BLES01807/PS3_GAME/PARAM.SFO","Grand Theft Auto V","BLES01807")
sfo(H+"/game/DEEPPLAY1/PARAM.SFO","Deep Play","DEEPPLAY1")
sfo(H+"/game/NPUB30001/PARAM.SFO","Flower","NPUB30001")
EOF
cat > $FAKE/wm.py <<EOF
import http.server,sys
class H(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        open("$LOG","a").write(self.path+"\n")
        try: self.send_response(200); self.end_headers(); self.wfile.write(b"ok")
        except Exception: pass
    def log_message(self,*a): pass
http.server.HTTPServer(("127.0.0.1",$PORT),H).serve_forever()
EOF
python3 $FAKE/wm.py & SRV=$!
make -s -B host PS3_ROOT=$FAKE WM_PORT=$PORT 2>&1 | grep -E "error" && exit 1
sleep 0.5
pass=0; fail=0
ok(){ if [ "$2" = "$3" ]; then echo "PASS  $1"; pass=$((pass+1)); else echo "FAIL  $1  (esperado '$2', obtenido '$3')"; fail=$((fail+1)); fi; }
cfg=$H/game/PS5LNCH00/USRDIR/config.txt
launch(){ rm -f $cfg $LOG; SCRIPT="$1" ./host 1280 720 $FAKE/x >/dev/null; tail -1 $LOG 2>/dev/null; }

ok "GTA V se detecta por PARAM.SFO y se lanza"      "/play.ps3/dev_hdd0/GAMES/BLES01807" "$(launch X)"
ok "Música abre el explorador de webMAN"            "/browser.ps3/dev_hdd0/music"        "$(launch R1,X)"
ok "Vídeos"                                         "/browser.ps3/dev_hdd0/video"        "$(launch R1,RIGHT,X)"
ok "Imágenes"                                       "/browser.ps3/dev_hdd0/photo"        "$(launch R1,RIGHT,RIGHT,X)"
ok "Deep Play (detectado en dev_hdd0/game)"         "/play.ps3?DEEPPLAY1"                "$(launch R1,R1,X)"
ok "multiMAN por nombre"                            "/play.ps3?multiman"                 "$(launch R1,R1,RIGHT,X)"
ok "webMAN MOD abre su interfaz web"                "/browser.ps3?http://127.0.0.1/"     "$(launch R1,R1,RIGHT,RIGHT,X)"
ok "Ajustes -> /setup.ps3"                          "/browser.ps3?http://127.0.0.1/setup.ps3" "$(launch R1,R1,RIGHT,RIGHT,RIGHT,RIGHT,X)"
ok "FIFA 19 se enlaza con la carpeta FIFA19_X"      "/play.ps3/dev_hdd0/GAMES/FIFA19_X" "$(launch RIGHT,X)"
rmdir $H/GAMES/FIFA19_X
ok "FIFA 19 NO instalado: no lanza nada"            "" "$(launch RIGHT,X)"

rm -f $cfg; SCRIPT="TRI,R1,R1" ./host 1280 720 $FAKE/x >/dev/null
ok "Favorito se guarda"                             "1" "$(grep -c '^fav=static:gtav' $cfg)"
ok "Última sección se guarda (Aplicaciones=2)"      "section=2" "$(grep '^section=' $cfg)"
r=$(SCRIPT="-" ./host 1280 720 $FAKE/x | grep -o 'exit=[0-9]')
ok "Reabre sin salir"                               "exit=0" "$r"
rm -f $cfg
SCRIPT="TRI,TRI" ./host 1280 720 $FAKE/x >/dev/null
ok "Quitar favorito lo elimina del archivo"         "0" "$(grep -c '^fav=' $cfg)"

SCRIPT="X$(printf ',-%.0s' $(seq 40))" ./host 1280 720 $FAKE/x | grep -q 'exit=1' && r=exit || r=no
ok "Tras lanzar, el launcher sale (exit_after)"     "exit" "$r"

kill $SRV; sleep 0.3
r=$(SCRIPT="X" ./host 1280 720 $FAKE/x | grep -o 'error=[0-9]')
ok "Con webMAN caído: error visible, no se cierra"  "error=1" "$r"
r=$(SCRIPT="X$(printf ',-%.0s' $(seq 40))" ./host 1280 720 $FAKE/x | grep -o 'exit=[0-9]')
ok "Con webMAN caído: el launcher NO sale"          "exit=0" "$r"

# savedata intacto: nada fuera de config.txt debe haber cambiado
ok "SAVEDATA1 no se toca"                           "0" "$(find $H/game/SAVEDATA1 -type f | wc -l)"
echo; echo "Resultado: $pass OK, $fail fallos"; [ $fail -eq 0 ]
