#pragma once
#include "../io/pad.h"
#define SYSUTIL_EXIT_GAME 0x0101
#define SYSUTIL_EVENT_SLOT0 0
typedef void (*sysutil_callback_t)(u64,u64,void*);
s32 sysUtilRegisterCallback(s32, sysutil_callback_t, void*); s32 sysUtilCheckCallback(void);
