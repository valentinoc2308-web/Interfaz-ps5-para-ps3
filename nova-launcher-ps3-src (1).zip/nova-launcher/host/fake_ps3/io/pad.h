/* FALSO: solo para comprobar sintaxis de MI código. Campos de padData según la doc de PSL1GHT. */
#pragma once
#include <stdint.h>
typedef uint32_t u32; typedef uint64_t u64; typedef int32_t s32; typedef uint16_t u16;
#define MAX_PADS 127
typedef struct { u32 max; u32 connected; u32 info; u16 vendor_id[127]; u16 product_id[127]; u16 status[127]; } padInfo;
typedef struct { s32 len; unsigned BTN_LEFT:1,BTN_DOWN:1,BTN_RIGHT:1,BTN_UP:1,BTN_START:1,BTN_R3:1,BTN_L3:1,BTN_SELECT:1,
  BTN_SQUARE:1,BTN_CROSS:1,BTN_CIRCLE:1,BTN_TRIANGLE:1,BTN_R1:1,BTN_L1:1,BTN_R2:1,BTN_L2:1; unsigned ANA_R_H:16,ANA_R_V:16,ANA_L_H:16,ANA_L_V:16; } padData;
s32 ioPadInit(u32); s32 ioPadEnd(void); s32 ioPadGetInfo(padInfo*); s32 ioPadGetData(u32, padData*);
