/* Backend de PRUEBAS en PC (no es parte del PKG). Ejecuta exactamente el mismo
 * código de ui/gfx/library/launch y escribe capturas PPM según un guion de
 * entradas. Uso: host_main <w> <h> <salida_prefijo> [raiz_falsa_ps3]
 * Guion: lista de "botones:fotogramas_hasta_captura" en la variable SCRIPT. */
#include "../src/ui.h"
#include "../src/input.h"
#include "../src/platform.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int g_sounds[SND_COUNT];
void plat_sound(int id) { if (id >= 0 && id < SND_COUNT) g_sounds[id]++; }

static void save_ppm(Surf *s, const char *path)
{
    FILE *f = fopen(path, "wb");
    if (!f) return;
    fprintf(f, "P6\n%d %d\n255\n", s->w, s->h);
    for (int i = 0; i < s->w * s->h; i++) {
        unsigned c = s->px[i];
        unsigned char rgb[3] = { (c >> 16) & 255, (c >> 8) & 255, c & 255 };
        fwrite(rgb, 1, 3, f);
    }
    fclose(f);
}

static unsigned parse_btn(const char *t)
{
    static const struct { const char *n; unsigned b; } m[] = {
        {"UP", PB_UP}, {"DOWN", PB_DOWN}, {"LEFT", PB_LEFT}, {"RIGHT", PB_RIGHT},
        {"X", PB_CROSS}, {"O", PB_CIRCLE}, {"TRI", PB_TRI}, {"L1", PB_L1}, {"R1", PB_R1}, {"-", 0}
    };
    for (unsigned i = 0; i < sizeof m / sizeof m[0]; i++) if (!strcmp(t, m[i].n)) return m[i].b;
    return 0;
}

int main(int argc, char **argv)
{
    if (argc < 4) { fprintf(stderr, "uso: %s w h prefijo\n", argv[0]); return 1; }
    int w = atoi(argv[1]), h = atoi(argv[2]);
    App *a = app_create(w, h);
    if (!a) return 1;
    const char *script = getenv("SCRIPT");
    if (!script) script = "-";
    char buf[1024];
    snprintf(buf, sizeof buf, "%s", script);
    int shot = 0, frames = 0;
    for (char *tok = strtok(buf, ","); tok; tok = strtok(NULL, ",")) {
        /* formato: BOTON  (pulsa 3 fotogramas + suelta 2)  |  BOTON*  (captura tras 40 fotogramas) */
        int capture = 0;
        char *star = strchr(tok, '*');
        if (star) { *star = 0; capture = 1; }
        unsigned b = parse_btn(tok);
        for (int i = 0; i < 3; i++) { app_frame(a, b, 1.f / 60.f); frames++; }
        for (int i = 0; i < (capture ? 45 : 2); i++) { app_frame(a, 0, 1.f / 60.f); frames++; }
        if (capture) {
            char path[256];
            snprintf(path, sizeof path, "%s_%02d.ppm", argv[3], shot++);
            save_ppm(app_surface(a), path);
        }
    }
    printf("frames=%d capturas=%d exit=%d sonidos: mover=%d sel=%d atras=%d seccion=%d error=%d\n",
           frames, shot, app_wants_exit(a), g_sounds[SND_MOVE], g_sounds[SND_SELECT],
           g_sounds[SND_BACK], g_sounds[SND_SECTION], g_sounds[SND_ERROR]);
    app_destroy(a);
    return 0;
}
