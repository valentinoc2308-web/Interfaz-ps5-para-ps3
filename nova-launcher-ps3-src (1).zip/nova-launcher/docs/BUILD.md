# Compilar el PKG

Este proyecto se desarrolló sin toolchain de PS3 (el entorno no tenía red para instalarla),
así que **el PKG no está generado**. Estos son los pasos para generarlo en tu PC.

## 1. Toolchain

Fuentes encontradas durante la investigación (proyecto abierto y legal; **no** es el SDK oficial de Sony):

- `ps3dev/ps3toolchain` — compila GCC/binutils para PPU y SPU.
- `ps3dev/PSL1GHT` — SDK libre (RSX, pad, sysutil, audio, red) y herramientas `sfo`, `pkg`, `fself`.

Sigue el README de `ps3toolchain` (Linux/macOS/WSL) y exporta:

```
export PS3DEV=/usr/local/ps3dev
export PSL1GHT=$PS3DEV
export PATH=$PATH:$PS3DEV/bin:$PS3DEV/ppu/bin
```

## 2. Compilar

```
make            # build_ps3/ps5launcher.self
make pkg        # .pkg instalable
make AUDIO=0 pkg   # si el audio no compila en tu versión de PSL1GHT
```

La documentación de PSL1GHT indica que el `.pkg` se arma con `sfo`/`pkg`, y que para HEN/CFW el
ejecutable va como SELF con firma falsa (`fself`). `APPID` es `PS5LNCH00` (9 caracteres; el
código lo usa también para localizar su `config.txt`).

## 3. Instalar en la PS3 (HEN 3.50, Super Slim)

1. Activa HEN en la consola (como haces habitualmente).
2. Copia el `.pkg` a USB (`/packages` o raíz) o a `/dev_hdd0/packages` con FTP/webMAN.
3. XMB → Juego → *Install Package Files* → instala. La app aparece en la columna Juego.

## 4. Primer build: puntos a verificar

Estos son los lugares donde asumí un patrón de PSL1GHT que no pude compilar. Si el compilador
protesta, busca `VERIFICAR` en el código:

| Archivo | Qué verificar |
|---|---|
| `Makefile` | Nombres de variables y reglas: compáralo con `samples/graphics/rsxtest/Makefile` de tu PSL1GHT (TITLE, APPID, CONTENTID, ICON0, `$(SELF)`, lista de `LIBS`) |
| `ps3/main_ps3.c` | Firma de `rsxInit(&ctx, cb, io, host)`; nombres `VIDEO_RESOLUTION_720`, `VIDEO_BUFFER_FORMAT_XRGB`, `VIDEO_ASPECT_AUTO`; campo `padInfo.status[]`; `netInitialize()`; `sysProcessExit()` |
| `ps3/audio_ps3.c` | Campos `readIndex`/`audioDataStart` de `audioPortConfig`, enums `AUDIO_PORT_2CH`/`AUDIO_BLOCK_8`, nombre del parámetro `attr` |
| `src/net_http.c` | Sockets: en PSL1GHT puede requerir `<net/net.h>` y funciones `net*()` en vez de las BSD |

Verificado contra documentación: `ioPadInit/ioPadGetInfo/ioPadGetData`, campos `BTN_*` y `ANA_*` de `padData`.

## 5. Si va lento

El render es por software. Opciones, de más a menos efecto:
- Editar `config.txt` (en `/dev_hdd0/game/PS5LNCH00/USRDIR/`) con `fx=0`: apaga las luces animadas del fondo; en reposo la pantalla no se redibuja.
- Mantener 720p (`RENDER_W/H` en el Makefile). La consola escala a tu TV 1080p.
- Medido en PC (x86 moderno): ~6–7 ms/fotograma a 720p, ~15 ms a 1080p; en reposo ≈ 0.

## 6. Limitaciones del sistema

- HEN 3.50 en Super Slim no es CFW completo: ciertas funciones del sistema no están disponibles; por eso el lanzamiento depende de webMAN MOD.
- HEN hay que reactivarlo en cada arranque. El launcher no lo toca.
- Una app homebrew solo ve lo que el sistema de archivos le permite; no se accede a savedata.
